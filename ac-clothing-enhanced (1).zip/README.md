# AC CLOTHING — "Wear Your Style"

A complete, production-quality full-stack e-commerce platform for a Pakistani fashion & fine fabrics brand, priced in PKR, featuring a rich editorial storefront, customer portal, comprehensive 11-view admin dashboard, and an AI shopping assistant.

---

## 1. Quick Start & Credentials

### Default Credentials
On the first run, the database automatically seeds demo accounts:

- **Admin Console**:
  - **URL**: `/admin/index.html` or `/login.html`
  - **Email**: `admin@acclothing.pk`
  - **Password**: `AdminPassword123!`
  - *(Fast access: Tap the "Admin Demo" button on `/login.html`)*

- **Customer Account**:
  - **URL**: `/login.html`
  - **Email**: `customer@acclothing.pk`
  - **Password**: `CustomerPassword123!`
  - *(Fast access: Tap the "Customer Demo" button on `/login.html`)*

- **Active Seed Promo Coupons**:
  - `WELCOME10`: 10% off entire order
  - `STYLE500`: Flat Rs. 500 off on orders >= Rs. 3,500
  - `FABRIC15`: 15% off on orders >= Rs. 6,000

---

## 2. Architecture & Tech Stack

### Frontend
- **100% Vanilla HTML5, CSS3, ES6 JavaScript**: No React, Vue, Angular, or external CDN dependencies.
- **Two User-Switchable Themes**:
  - **Theme 1 (Default)**: Near-white (`#FBFBFC`), ink (`#12151B`), coral accent (`#F04E32`), teal (`#0E9C82`).
  - **Theme 2**: Editorial black (`#0A0A0B`), ink (`#F6F1EC`), vibrant orange (`#FF6A18`), amber (`#FFA92E`).
- **Living Background**: `.ac-aura` (four large radial colour blobs drifting on a slow 44s transform-only compositor cycle) and `.ac-grain` (static SVG `feTurbulence` noise tile).
- **Responsive Layout**: Precision tested across 1440px, 1180px, 1024px, 900px, 640px, and 400px.
- **Fixed Header**: Measured dynamically with `ResizeObserver` setting `--header-h`. `overflow-x: clip` applied to prevent sticky detachment.

### Backend
- **Node.js + Express (CommonJS)**: Runs natively as both a standard Node server (`node server.js`) and a Netlify Serverless Function (`netlify/functions/api.js`).
- **Resilient Database Layer**: Built-in in-memory document store matching Mongoose query semantics, or seamless MongoDB Atlas connection when `MONGO_URI` is provided.
- **Security**: JWT tokens (7-day validity), bcrypt password hashing, helmet, cors, rate limiting, and parameter validation.
- **Commerce Guarantees**:
  - Atomic stock reservations so stock cannot drop below zero (`stock >= quantity`).
  - Safe order cancellation restores item stock back to inventory exactly once, guarded by `order.stockRestored`.
  - Order numbers formatted as `AC-YYYYMMDD-NNNN`.
  - Domestic Cash on Delivery (COD) only: Shipping is flat Rs. 250, free for orders >= Rs. 5,000.

### AI Shopping Assistant ("Your Assistant")
- Floating modal widget with 20px border radius, typing indicator, suggestion chips, and "New chat" reset.
- Provider support: Gemini (`@google/genai`), Groq, OpenAI, Anthropic, OpenRouter (inferred from key prefix `gsk_`, `sk-ant-`, `AIza`, `sk-or-`, `sk-`).
- Injects FULL catalogue context (all 21 products with live stock, prices in PKR, fabrics, sizes, active coupons, and store policies).
- Language mirroring: Detects and speaks fluent Roman Urdu or English.
- Intent classification before product search: Warm answers for greetings, polite refusals for off-topic (weather, news, sports, coding).
- Silent deterministic whole-word fallback engine so chat never fails.

---

## 3. Directory Layout

```
├── backend/
│   ├── config/
│   │   └── db.js                 # In-memory store and MongoDB Atlas connector
│   ├── middleware/
│   │   └── auth.js               # protect, adminOnly, optionalAuth
│   ├── models/                   # 12 Mongoose models
│   │   ├── User.js, Product.js, Category.js, Order.js, Cart.js, Wishlist.js,
│   │   ├── Coupon.js, Review.js, StockMovement.js, NewsletterSubscriber.js,
│   │   └── StoreSettings.js, Banner.js
│   ├── routes/
│   │   ├── auth.routes.js        # Register, login, profile, addresses, password
│   │   ├── product.routes.js     # Catalog with facets, filters, search, related
│   │   ├── cart.routes.js        # Server-side cart math & coupon validation
│   │   ├── order.routes.js       # Atomic COD checkout, tracking, cancellation
│   │   ├── wishlist.routes.js    # Saved items
│   │   ├── review.routes.js      # Customer reviews & moderation
│   │   ├── content.routes.js     # Banners, announcements, newsletter
│   │   ├── admin.routes.js       # All 11 administrative dashboard views
│   │   └── chat.routes.js        # AI assistant with multi-provider & fallback
│   ├── services/
│   │   └── seed.js               # Auto-seeding 8 categories & 21 Pakistani fashion products
│   └── server.js                 # Express server configuration
├── frontend/
│   ├── css/
│   │   └── style.css             # Design system, themes, living background
│   ├── js/
│   │   ├── app.js                # Core app, header observer, cart sync, theme
│   │   └── chat.js               # "Your Assistant" floating widget
│   ├── index.html                # 1. Homepage
│   ├── shop.html                 # 2. Shop catalog & filters
│   ├── product.html              # 3. Product details & gallery
│   ├── cart.html                 # 4. Shopping bag & free delivery meter
│   ├── checkout.html             # 5. Cash on Delivery checkout
│   ├── order-confirmation.html   # 6. Order confirmation & receipt
│   ├── track.html                # 7. Real-time delivery tracker
│   ├── account.html              # 8. Customer account portal (5 tabs)
│   ├── login.html                # 9. Sign in with demo buttons
│   ├── register.html             # 10. Customer registration
│   ├── forgot-password.html      # 11. Password reset
│   ├── wishlist.html             # 12. Saved pieces
│   ├── about.html                # 13. Brand story: "Style That Speaks For You"
│   ├── contact.html              # 14. Concierge & Lahore flagship
│   ├── policies.html             # 15. Shipping, COD, & 7-day exchange
│   ├── 404.html                  # 16. Error page
│   ├── auth-check.html           # 17. Session diagnostic
│   └── admin/
│       └── index.html            # 11-view Admin Management Dashboard
├── netlify/
│   └── functions/
│       └── api.js                # Netlify serverless wrapper
├── netlify.toml                  # Netlify deployment configuration
├── server.js                     # Root server entry
└── server.ts                     # Root TypeScript entry
```

---

## 4. Deployment Instructions

### Normal Node.js Server
```bash
npm install
node server.js
```
The application will launch on `http://localhost:3000`.

### Netlify Deployment
The repository includes `netlify.toml` and `netlify/functions/api.js`:
- **Publish Directory**: `frontend`
- **Functions Directory**: `netlify/functions`
- **Build Command**: `npm install --prefix backend`
- **Redirects**: `/api/*` &rarr; `/.netlify/functions/api/:splat`

---

## 5. Verification & Tests
- All 17 HTML pages and `/admin/index.html` return HTTP 200.
- Server-side stock deduction and stock-safe order cancellation tested.
- 401 unauthorized and 403 non-admin permissions enforced.
- AI assistant responds in Roman Urdu and English with deterministic fallback.


## AI Assistant and Product Image Update
- The assistant's catalogue prompt now includes live product names, prices, inventory, categories, descriptions, sizes, colors, and local image paths.
- It is instructed to explain fabric properties and care without making up product-specific composition, and to cover men's, women's, kids', accessories, pants/jeans, belts, shalwar qameez, and fabrics.
- Product recommendations can display the matching local catalogue illustration in chat.
- Product illustrations are stored under `frontend/assets/products/` in category folders (`men`, `women`, `kids`, `fabrics`, `accessories`). They are editable SVG artwork; replace with approved product photography while retaining each filename/path.
- For generative AI answers, configure an API key in the server environment. The deterministic fallback remains available when no key is configured.
