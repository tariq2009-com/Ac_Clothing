/**
 * AC CLOTHING — Authentication Middleware
 * Powered by Firebase Authentication and Realtime Database.
 */
const jwt = require('jsonwebtoken');
const { getUserById, getUserByEmail, db } = require('../services/firebase');

const JWT_SECRET = process.env.JWT_SECRET || 'ac_clothing_jwt_super_secret_key_change_in_production_2026';
const ADMIN_EMAIL = 'tariqadmin@gmail.com';

// Protect routes - requires valid session or Firebase token
async function protect(req, res, next) {
  let token;

  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  } else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  if (!token) {
    return res.status(401).json({
      success: false,
      message: 'Access denied. Please sign in to continue.'
    });
  }

  try {
    let uid = null;
    let email = null;

    // Check if it's our signed JWT
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      uid = decoded.id || decoded.uid;
      email = decoded.email;
    } catch (e) {
      // If not JWT, check if it's a Firebase UID or client token
      // Many client calls pass the direct Firebase user UID or base64 token
      if (token.length < 128 && !token.includes('.')) {
        uid = token;
      }
    }

    let user = null;
    if (uid) {
      user = await getUserById(uid);
    }
    if (!user && email) {
      user = await getUserByEmail(email);
    }

    // Fallback: If user is admin email directly
    if (!user && email && email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      user = { uid: 'admin-master', email: ADMIN_EMAIL, role: 'admin', name: 'AC Administrator' };
    }

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'The user account could not be found or session has expired.'
      });
    }

    // Role enforcement
    if (user.email && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
      user.role = 'admin';
    }

    const safeUser = { ...user };
    delete safeUser.password;
    req.user = safeUser;
    next();
  } catch (err) {
    return res.status(401).json({
      success: false,
      message: 'Invalid or expired session. Please sign in again.'
    });
  }
}

// Require admin role
function adminOnly(req, res, next) {
  if (!req.user) {
    return res.status(401).json({
      success: false,
      message: 'Please sign in with administrator credentials.'
    });
  }

  const isAdmin = req.user.role === 'admin' || 
    (req.user.email && req.user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());

  if (!isAdmin) {
    return res.status(403).json({
      success: false,
      message: 'Forbidden. Administrator privileges required.'
    });
  }
  next();
}

// Optional authentication
async function optionalAuth(req, res, next) {
  let token;
  if (req.headers.authorization && req.headers.authorization.startsWith('Bearer ')) {
    token = req.headers.authorization.split(' ')[1];
  } else if (req.cookies && req.cookies.token) {
    token = req.cookies.token;
  }

  if (token) {
    try {
      let uid = null;
      try {
        const decoded = jwt.verify(token, JWT_SECRET);
        uid = decoded.id || decoded.uid;
      } catch (e) {
        if (token.length < 128 && !token.includes('.')) {
          uid = token;
        }
      }
      if (uid) {
        const user = await getUserById(uid);
        if (user) {
          if (user.email && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) {
            user.role = 'admin';
          }
          const safeUser = { ...user };
          delete safeUser.password;
          req.user = safeUser;
        }
      }
    } catch (e) {}
  }
  next();
}

module.exports = {
  protect,
  adminOnly,
  optionalAuth,
  JWT_SECRET,
  ADMIN_EMAIL
};
