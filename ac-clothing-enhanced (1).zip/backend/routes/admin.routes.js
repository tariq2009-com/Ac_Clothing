/**
 * AC CLOTHING — Admin Management Routes
 * Powered by Firebase Realtime Database.
 * Strictly guarded by protect + adminOnly middleware.
 */
const express = require('express');
const router = express.Router();
const {
  db,
  getProducts,
  getProductById,
  saveProduct,
  updateProduct,
  deleteProduct,
  getCategories,
  getOrders,
  getOrderById,
  getUsers,
  getCoupons,
  getReviews
} = require('../services/firebase');
const { protect, adminOnly } = require('../middleware/auth');

router.use(protect);
router.use(adminOnly);

// 1. GET /api/admin/dashboard/stats — Core Analytics
router.get('/dashboard/stats', async (req, res) => {
  try {
    const products = await getProducts();
    const orders = await getOrders();
    const users = await getUsers();

    const totalProducts = products.length;
    let soldProducts = 0;
    let remainingStock = 0;

    products.forEach(p => {
      soldProducts += (Number(p.soldCount) || 0);
      remainingStock += (Number(p.stock) || 0);
    });

    const totalOrders = orders.length;
    const totalRevenue = orders
      .filter(o => o.status !== 'Cancelled')
      .reduce((sum, o) => sum + (Number(o.totalAmount) || 0), 0);

    const pendingOrders = orders.filter(o => o.status === 'Pending').length;

    res.json({
      success: true,
      stats: {
        totalProducts,
        soldProducts,
        remainingStock,
        totalOrders,
        totalRevenue,
        pendingOrders,
        totalCustomers: users.length,
        recentOrders: orders.slice(0, 8),
        lowStockItems: products.filter(p => Number(p.stock) <= 8).slice(0, 6)
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 2. Products Management
router.get('/products', async (req, res) => {
  try {
    const products = await getProducts();
    res.json({ success: true, products });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/products', async (req, res) => {
  try {
    const {
      name,
      category,
      subcategory,
      brand,
      gender,
      price,
      compareAtPrice,
      stock,
      description,
      fabric,
      colors,
      sizes,
      image,
      images,
      isNew
    } = req.body;

    if (!name || !price || !category) {
      return res.status(400).json({ success: false, message: 'Name, price, and category are required.' });
    }

    const id = `prod-${Date.now()}`;
    const productImages = Array.isArray(images) && images.length ? images : (image ? [image] : ['/assets/products/men/polo-tee.svg']);

    const newProd = {
      id,
      _id: id,
      slug: name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/(^-|-$)+/g, '') || id,
      name: name.trim(),
      category: category.trim(),
      subcategory: subcategory ? subcategory.trim() : '',
      brand: brand ? brand.trim() : 'AC CLOTHING',
      gender: gender || 'unisex',
      price: Number(price),
      compareAtPrice: compareAtPrice ? Number(compareAtPrice) : null,
      stock: Number(stock) || 0,
      soldCount: 0,
      isNew: isNew !== undefined ? Boolean(isNew) : true,
      isNewArrival: isNew !== undefined ? Boolean(isNew) : true,
      description: description || '',
      fabric: fabric || 'Pure Combed Cotton',
      colors: Array.isArray(colors) ? colors : (typeof colors === 'string' ? colors.split(',').map(c => c.trim()) : ['Black', 'White']),
      sizes: Array.isArray(sizes) ? sizes : (typeof sizes === 'string' ? sizes.split(',').map(s => s.trim()) : ['S', 'M', 'L', 'XL']),
      image: productImages[0],
      images: productImages,
      createdAt: new Date().toISOString()
    };

    const saved = await saveProduct(newProd);
    res.status(201).json({ success: true, product: saved, message: 'Product created successfully!' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.put('/products/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;
    if (updates.price !== undefined) updates.price = Number(updates.price);
    if (updates.stock !== undefined) updates.stock = Number(updates.stock);
    if (updates.isNew !== undefined) {
      updates.isNew = Boolean(updates.isNew);
      updates.isNewArrival = Boolean(updates.isNew);
    }

    const updated = await updateProduct(id, updates);
    res.json({ success: true, product: updated, message: 'Product updated successfully!' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.patch('/products/:id/toggle-new', async (req, res) => {
  try {
    const { id } = req.params;
    const product = await getProductById(id);
    if (!product) return res.status(404).json({ success: false, message: 'Product not found' });

    const newStatus = !product.isNew;
    const updated = await updateProduct(id, { isNew: newStatus, isNewArrival: newStatus });
    res.json({ success: true, isNew: newStatus, product: updated, message: `Product marked as ${newStatus ? 'NEW' : 'OLD'}` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.patch('/products/:id/stock', async (req, res) => {
  try {
    const { id } = req.params;
    const { stock } = req.body;
    if (stock === undefined) return res.status(400).json({ success: false, message: 'Stock value required' });

    const updated = await updateProduct(id, { stock: Number(stock) });
    res.json({ success: true, product: updated, message: 'Stock updated' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.patch('/products/:id/price', async (req, res) => {
  try {
    const { id } = req.params;
    const { price } = req.body;
    if (price === undefined) return res.status(400).json({ success: false, message: 'Price value required' });

    const updated = await updateProduct(id, { price: Number(price) });
    res.json({ success: true, product: updated, message: 'Price updated' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.delete('/products/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await deleteProduct(id);
    res.json({ success: true, message: 'Product deleted from Firebase RTDB' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 3. Orders Management
router.get('/orders', async (req, res) => {
  try {
    const orders = await getOrders();
    res.json({ success: true, orders });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.put('/orders/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    const order = await getOrderById(id);
    if (!order) return res.status(404).json({ success: false, message: 'Order not found' });

    await db.update(`orders/${order.id}`, {
      status,
      updatedAt: new Date().toISOString()
    });

    res.json({ success: true, message: `Order #${order.orderNumber} status changed to ${status}` });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 4. Customers Management
router.get('/customers', async (req, res) => {
  try {
    const users = await getUsers();
    const orders = await getOrders();

    const customers = users.map(u => {
      const uOrders = orders.filter(o => o.userId === u.uid || (o.customer && o.customer.email === u.email));
      const totalSpent = uOrders.filter(o => o.status !== 'Cancelled').reduce((s, o) => s + (o.totalAmount || 0), 0);

      const safe = { ...u };
      delete safe.password;
      return {
        ...safe,
        ordersCount: uOrders.length,
        totalSpent
      };
    });

    res.json({ success: true, customers });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 5. Inventory Overview
router.get('/inventory', async (req, res) => {
  try {
    const products = await getProducts();
    const inventory = products.map(p => ({
      id: p.id,
      _id: p.id,
      name: p.name,
      category: p.category,
      stock: p.stock,
      soldCount: p.soldCount,
      price: p.price,
      isLowStock: Number(p.stock) <= 8
    }));

    res.json({ success: true, inventory });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 6. Categories
router.get('/categories', async (req, res) => {
  try {
    const categories = await getCategories();
    res.json({ success: true, categories });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/categories', async (req, res) => {
  try {
    const { name, slug, gender, description, image } = req.body;
    const catSlug = slug || name.toLowerCase().replace(/[^a-z0-9]+/g, '-');
    await db.set(`categories/${catSlug}`, {
      name,
      slug: catSlug,
      gender: gender || 'all',
      description: description || '',
      image: image || ''
    });
    res.status(201).json({ success: true, message: 'Category added' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 7. Coupons
router.get('/coupons', async (req, res) => {
  try {
    const coupons = await getCoupons();
    res.json({ success: true, coupons });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/coupons', async (req, res) => {
  try {
    const { code, discountType, discountValue, minOrderValue, description } = req.body;
    const cId = `coup-${Date.now()}`;
    await db.set(`coupons/${cId}`, {
      id: cId,
      code: code.toUpperCase().trim(),
      discountType: discountType || 'percentage',
      discountValue: Number(discountValue),
      minOrderValue: Number(minOrderValue) || 0,
      description: description || '',
      isActive: true,
      createdAt: new Date().toISOString()
    });
    res.status(201).json({ success: true, message: 'Coupon created' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.delete('/coupons/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await db.remove(`coupons/${id}`);
    res.json({ success: true, message: 'Coupon deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 8. Reviews
router.get('/reviews', async (req, res) => {
  try {
    const reviews = await getReviews();
    res.json({ success: true, reviews });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.put('/reviews/:id/moderation', async (req, res) => {
  try {
    const { id } = req.params;
    const { isModerated } = req.body;
    await db.update(`reviews/${id}`, { isModerated: Boolean(isModerated) });
    res.json({ success: true, message: 'Review moderation updated' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.delete('/reviews/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await db.remove(`reviews/${id}`);
    res.json({ success: true, message: 'Review deleted' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 9. Banners & Content
router.get('/content/banners', async (req, res) => {
  try {
    const banners = await db.get('banners') || {};
    res.json({
      success: true,
      banners: Object.entries(banners).map(([k, v]) => ({ _id: k, id: k, ...v }))
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.post('/content/banners', async (req, res) => {
  try {
    const id = `banner-${Date.now()}`;
    await db.set(`banners/${id}`, { id, ...req.body });
    res.status(201).json({ success: true, message: 'Banner saved' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.delete('/content/banners/:id', async (req, res) => {
  try {
    const { id } = req.params;
    await db.remove(`banners/${id}`);
    res.json({ success: true, message: 'Banner removed' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 10. Store Settings
router.get('/settings', async (req, res) => {
  try {
    const settings = await db.get('settings') || {};
    res.json({ success: true, settings });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

router.put('/settings', async (req, res) => {
  try {
    await db.update('settings', req.body);
    res.json({ success: true, message: 'Settings updated' });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// 11. AI Diagnostics
router.get('/ai-assistant', async (req, res) => {
  try {
    const products = await getProducts();
    const coupons = await getCoupons();

    res.json({
      success: true,
      diagnostics: {
        provider: process.env.GEMINI_API_KEY ? 'gemini' : 'deterministic-fallback',
        status: 'Operational',
        model: 'gemini-2.5-flash',
        catalogueItemsSynced: products.length,
        activeCouponsSynced: coupons.filter(c => c.isActive).length
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
