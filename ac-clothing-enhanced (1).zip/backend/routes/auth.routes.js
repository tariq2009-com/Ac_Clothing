/**
 * AC CLOTHING — Authentication Routes
 * Powered by Firebase Authentication & Realtime Database.
 */
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const {
  db,
  getUsers,
  getUserById,
  getUserByEmail
} = require('../services/firebase');
const { protect, JWT_SECRET, ADMIN_EMAIL } = require('../middleware/auth');

const INITIAL_WALLET_BALANCE = 30000;

function signToken(userId, role, email) {
  return jwt.sign({ id: userId, uid: userId, role, email }, JWT_SECRET, { expiresIn: '7d' });
}

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const { name, email, password, phone } = req.body;

    if (!name || !email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Name, email and password are required.'
      });
    }

    if (password.length < 6) {
      return res.status(400).json({
        success: false,
        message: 'Password must be at least 6 characters long.'
      });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const existing = await getUserByEmail(normalizedEmail);
    if (existing) {
      return res.status(400).json({
        success: false,
        message: 'An account with this email address already exists.'
      });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    const isAdmin = normalizedEmail === ADMIN_EMAIL.toLowerCase();
    const role = isAdmin ? 'admin' : 'customer';
    const uid = 'usr_' + Date.now() + '_' + Math.random().toString(36).slice(2, 7);

    // Initial user profile with Rs. 30,000 wallet balance
    const newUser = {
      uid,
      id: uid,
      _id: uid,
      name: name.trim(),
      email: normalizedEmail,
      password: hashedPassword,
      phone: phone ? phone.trim() : '',
      role,
      walletBalance: INITIAL_WALLET_BALANCE,
      walletGranted: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      addresses: phone ? [{
        id: 'addr-1',
        label: 'Default Address',
        street: '',
        city: 'Lahore',
        postalCode: '',
        phone: phone.trim(),
        isDefault: true
      }] : []
    };

    // Save to Firebase Realtime Database
    await db.set(`users/${uid}`, newUser);

    // Record initial welcome credit transaction in Firebase RTDB
    await db.push(`transactions/${uid}`, {
      type: 'CREDIT',
      amount: INITIAL_WALLET_BALANCE,
      description: 'AC Clothing Welcome Gift — Rs. 30,000 Virtual Store Credit',
      balanceAfter: INITIAL_WALLET_BALANCE,
      date: new Date().toISOString()
    });

    const token = signToken(uid, role, normalizedEmail);
    const safeUser = { ...newUser };
    delete safeUser.password;

    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    res.status(201).json({
      success: true,
      token,
      user: safeUser,
      message: 'Account created successfully! Welcome to AC CLOTHING. You received Rs. 30,000 store credit!'
    });
  } catch (err) {
    console.error('Registration error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      return res.status(400).json({
        success: false,
        message: 'Please provide both email and password.'
      });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const user = await getUserByEmail(normalizedEmail);

    if (!user) {
      return res.status(401).json({
        success: false,
        message: 'No account found with this email address.'
      });
    }

    // Verify password if user was created with a password
    if (user.password) {
      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.status(401).json({
          success: false,
          message: 'Invalid password. Please check your credentials.'
        });
      }
    }

    // Ensure admin role for admin email
    if (normalizedEmail === ADMIN_EMAIL.toLowerCase()) {
      user.role = 'admin';
      await db.update(`users/${user.uid}`, { role: 'admin' });
    }

    const token = signToken(user.uid, user.role, normalizedEmail);
    const safeUser = { ...user };
    delete safeUser.password;

    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    res.json({
      success: true,
      token,
      user: safeUser,
      message: `Welcome back, ${safeUser.name}!`
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/auth/sync — Synchronize Firebase Client Auth (Google or Modular SDK)
router.post('/sync', async (req, res) => {
  try {
    const { uid, email, name, phone } = req.body;
    if (!uid || !email) {
      return res.status(400).json({ success: false, message: 'UID and email are required.' });
    }

    const normalizedEmail = email.toLowerCase().trim();
    const isAdmin = normalizedEmail === ADMIN_EMAIL.toLowerCase();
    const role = isAdmin ? 'admin' : 'customer';

    let user = await getUserById(uid);
    let isNewUser = false;

    if (!user) {
      // First time registration: Grant Rs. 30,000 store credit once!
      isNewUser = true;
      user = {
        uid,
        id: uid,
        _id: uid,
        name: name || normalizedEmail.split('@')[0],
        email: normalizedEmail,
        phone: phone || '',
        role,
        walletBalance: INITIAL_WALLET_BALANCE,
        walletGranted: true,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        addresses: []
      };

      await db.set(`users/${uid}`, user);

      // Record welcome transaction
      await db.push(`transactions/${uid}`, {
        type: 'CREDIT',
        amount: INITIAL_WALLET_BALANCE,
        description: 'AC Clothing Welcome Gift — Rs. 30,000 Virtual Store Credit',
        balanceAfter: INITIAL_WALLET_BALANCE,
        date: new Date().toISOString()
      });
    } else {
      // Existing user: check if admin or profile update
      const updates = {};
      if (isAdmin && user.role !== 'admin') updates.role = 'admin';
      if (name && !user.name) updates.name = name;
      if (Object.keys(updates).length > 0) {
        await db.update(`users/${uid}`, updates);
        user = { ...user, ...updates };
      }
    }

    const token = signToken(uid, user.role, normalizedEmail);
    const safeUser = { ...user };
    delete safeUser.password;

    res.cookie('token', token, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    res.json({
      success: true,
      token,
      user: safeUser,
      isNewUser
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/auth/me — Current Profile & Wallet
router.get('/me', protect, async (req, res) => {
  try {
    const user = await getUserById(req.user.uid || req.user.id);
    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const safeUser = { ...user };
    delete safeUser.password;

    // Fetch transactions
    const txRaw = await db.get(`transactions/${user.uid}`);
    const transactions = txRaw ? Object.entries(txRaw).map(([k, v]) => ({ id: k, ...v })).reverse() : [];

    res.json({
      success: true,
      user: safeUser,
      wallet: {
        balance: user.walletBalance !== undefined ? user.walletBalance : INITIAL_WALLET_BALANCE,
        currency: 'PKR',
        symbol: 'Rs.',
        transactions
      }
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/auth/wallet — Wallet Balance & Ledger
router.get('/wallet', protect, async (req, res) => {
  try {
    const uid = req.user.uid || req.user.id;
    const user = await getUserById(uid);
    const txRaw = await db.get(`transactions/${uid}`);
    const transactions = txRaw ? Object.entries(txRaw).map(([k, v]) => ({ id: k, ...v })).reverse() : [];

    res.json({
      success: true,
      balance: user && user.walletBalance !== undefined ? user.walletBalance : INITIAL_WALLET_BALANCE,
      transactions
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// PUT /api/auth/profile
router.put('/profile', protect, async (req, res) => {
  try {
    const uid = req.user.uid || req.user.id;
    const { name, phone } = req.body;
    const updates = {};
    if (name) updates.name = name.trim();
    if (phone) updates.phone = phone.trim();
    updates.updatedAt = new Date().toISOString();

    await db.update(`users/${uid}`, updates);
    const updated = await getUserById(uid);
    delete updated.password;

    res.json({
      success: true,
      user: updated,
      message: 'Profile updated successfully'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
  res.clearCookie('token');
  res.json({ success: true, message: 'Logged out successfully' });
});

module.exports = router;
