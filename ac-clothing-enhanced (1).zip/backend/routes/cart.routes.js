/**
 * AC CLOTHING — Cart & Coupon Calculation Routes
 * Powered by Firebase Realtime Database.
 */
const express = require('express');
const router = express.Router();
const {
  getProductById,
  getCouponByCode
} = require('../services/firebase');

// POST /api/cart/calculate
router.post('/calculate', async (req, res) => {
  try {
    const { items, couponCode } = req.body;

    if (!Array.isArray(items) || items.length === 0) {
      return res.json({
        success: true,
        items: [],
        subtotal: 0,
        discountAmount: 0,
        shippingFee: 250,
        total: 250,
        appliedCoupon: null
      });
    }

    let subtotal = 0;
    const validatedItems = [];

    for (const item of items) {
      const pId = item.productId || item.id || item._id;
      if (!pId) continue;

      const product = await getProductById(pId);
      if (!product) continue;

      const qty = Math.max(1, parseInt(item.quantity, 10) || 1);
      const itemTotal = (product.price || 0) * qty;
      subtotal += itemTotal;

      validatedItems.push({
        productId: product.id,
        _id: product.id,
        name: product.name,
        price: product.price,
        quantity: qty,
        size: item.size || 'Standard',
        color: item.color || '',
        image: product.image || (product.images && product.images[0]) || '',
        stock: product.stock,
        itemTotal
      });
    }

    // Shipping logic (Free above 5000 PKR, else 250 PKR)
    let shippingFee = subtotal >= 5000 || subtotal === 0 ? 0 : 250;
    let discountAmount = 0;
    let appliedCoupon = null;

    if (couponCode && couponCode.trim()) {
      const coupon = await getCouponByCode(couponCode.trim());
      if (coupon && coupon.isActive) {
        if (!coupon.minOrderValue || subtotal >= coupon.minOrderValue) {
          if (coupon.discountType === 'percentage') {
            discountAmount = Math.round((subtotal * coupon.discountValue) / 100);
          } else if (coupon.discountType === 'fixed') {
            discountAmount = Math.min(subtotal, coupon.discountValue);
          }
          appliedCoupon = {
            code: coupon.code,
            description: coupon.description,
            discountAmount
          };
        }
      }
    }

    const total = Math.max(0, subtotal - discountAmount + shippingFee);

    res.json({
      success: true,
      items: validatedItems,
      subtotal,
      discountAmount,
      shippingFee,
      total,
      appliedCoupon
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/cart/validate-coupon
router.post('/validate-coupon', async (req, res) => {
  try {
    const { code, subtotal = 0 } = req.body;
    if (!code) {
      return res.status(400).json({ success: false, message: 'Coupon code is required.' });
    }

    const coupon = await getCouponByCode(code);
    if (!coupon || !coupon.isActive) {
      return res.status(404).json({ success: false, message: 'Invalid or expired coupon code.' });
    }

    if (coupon.minOrderValue && Number(subtotal) < coupon.minOrderValue) {
      return res.status(400).json({
        success: false,
        message: `This coupon requires a minimum order value of Rs. ${coupon.minOrderValue.toLocaleString('en-PK')}.`
      });
    }

    let discount = 0;
    if (coupon.discountType === 'percentage') {
      discount = Math.round((Number(subtotal) * coupon.discountValue) / 100);
    } else {
      discount = Math.min(Number(subtotal), coupon.discountValue);
    }

    res.json({
      success: true,
      coupon: {
        code: coupon.code,
        discountType: coupon.discountType,
        discountValue: coupon.discountValue,
        discountAmount: discount,
        description: coupon.description
      },
      message: `Coupon "${coupon.code}" applied successfully!`
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
