/**
 * AC CLOTHING — AI Shopping Assistant ("Your Assistant")
 * Implements multi-provider AI support (Gemini, Groq, OpenAI, Anthropic, OpenRouter)
 * with full catalogue context, strict whole-word classification, and deterministic fallback.
 */
const express = require('express');
const router = express.Router();
const { getProducts, getCategories, getCoupons, db } = require('../services/firebase');

// Helper: Whole-word regex matching
function hasWord(text, word) {
  const re = new RegExp(`\\b${word}\\b`, 'i');
  return re.test(text);
}

// Helper: Check if query contains any of words
function hasAnyWord(text, words) {
  return words.some(w => hasWord(text, w));
}

// Helper: Detect Roman Urdu vs English
function isRomanUrdu(text) {
  const urduMarkers = [
    'kya', 'hai', 'hain', 'mein', 'mujhe', 'chahiye', 'batao', 'kitne', 'ka', 'ki',
    'ke', 'ye', 'yeh', 'kese', 'kaise', 'kapray', 'kapra', 'lawn', 'bhai', 'ap',
    'aap', 'shukriya', 'kuch', 'acha', 'salam', 'walaikum', 'kon', 'konsa', 'konsi',
    'bhejo', 'dikhao', 'pehn'
  ];
  const words = text.toLowerCase().split(/\s+/);
  const matchCount = words.filter(w => urduMarkers.includes(w)).length;
  return matchCount >= 1;
}

// Deterministic Rules Engine Fallback
function deterministicAnswer(question, products, categories, coupons, settings) {
  const text = question.trim().toLowerCase();
  const roman = isRomanUrdu(text);

  // 1. Classification: Greetings
  if (hasAnyWord(text, ['salam', 'aoa', 'assalam', 'assalamualaikum', 'hello', 'hi', 'hey', 'greetings'])) {
    if (roman) {
      return "Walaikum Assalam! AC CLOTHING mein khushamdeed. Main apka personal shopping assistant hoon. Aj ap kis tarah ka jora ya fabric dekhna chahein gay? (Lawn, Pret, Chiffon, Men's Kurta)";
    }
    return "Welcome to AC CLOTHING. I am Your Assistant. How may I assist your style journey today? You can ask about our Lawn suites, Pret tunics, Luxury formals, Men's kurtas, or order tracking.";
  }

  // 2. Classification: "How are you" / "Who are you" / Website identity
  if (hasAnyWord(text, ['who are you', 'kon ho', 'ap kon', 'what is this website', 'ye kya hai', 'about ac clothing', 'how are you', 'kese ho', 'kaise ho'])) {
    if (roman) {
      return "Main AC CLOTHING ka AI shopping assistant hoon. AC CLOTHING Pakistan ka luxury fashion brand hai jahan apko premium Unstitched Lawn, Ready-to-Wear Pret, Chiffon Formals aur Men's Boski kurtay miltay hain. Main apko sahi jora muntakhab karnay mein madad de sakta hoon.";
    }
    return "I am Your Assistant at AC CLOTHING. AC CLOTHING is a premier Pakistani fashion and fabrics house offering premium Unstitched Lawn, Ready-to-Wear Pret, Luxury Chiffon Formals, and Men's Kurtas. I can assist you with sizing, fabrics, pricing, and styling advice.";
  }

  // 3. Classification: Gratitude & Farewells
  if (hasAnyWord(text, ['shukriya', 'meherbani', 'thanks', 'thank you', 'bye', 'allah hafiz', 'khuda hafiz', 'goodbye'])) {
    if (roman) {
      return "Bohat shukriya! Agar mazeed kisi cheez ki zaroorat ho toh bataye ga. AC CLOTHING ke sath apka din khushgawar guzray!";
    }
    return "You are most welcome. It is our pleasure to assist you at AC CLOTHING. Have a wonderful day!";
  }

  // 4. Classification: Out of scope (weather, news, sports, coding, date, politics)
  if (hasAnyWord(text, ['weather', 'mausam', 'date', 'tarikh', 'time', 'waqt', 'cricket', 'match', 'news', 'khabar', 'politics', 'pm', 'python', 'javascript', 'code', 'coding', 'recipe', 'movie'])) {
    if (roman) {
      return "Maazrat, main sirf AC CLOTHING ke kapron, fabrics, orders aur styling ke baray mein rehnumai kar sakta hoon. Fashion ya shopping ke mutaliq sawal poochein!";
    }
    return "I specialize exclusively in AC CLOTHING collections, fabric care, sizing, and order assistance. Please let me know how I can assist with your wardrobe or shopping.";
  }

  // 5. Classification: Shipping & Delivery
  if (hasAnyWord(text, ['shipping', 'delivery', 'charges', 'free shipping', 'charges kitne', 'delivery time', 'days'])) {
    if (roman) {
      return "AC CLOTHING pure Pakistan mein Cash on Delivery par deliver karta hai. Standard delivery charges Rs. 250 hain, aur Rs. 5,000 se zyada ke order par FREE delivery hai. Delivery mein 3 se 5 karobari din lagtay hain.";
    }
    return "Standard shipping across Pakistan is Rs. 250, and delivery is completely FREE on orders of Rs. 5,000 or above. Orders are delivered via reliable courier within 3 to 5 business days with Cash on Delivery.";
  }

  // 6. Classification: Payment Methods & COD
  if (hasAnyWord(text, ['cod', 'payment', 'card', 'online payment', 'cash on delivery', 'paise'])) {
    if (roman) {
      return "Hum filhal pure Pakistan mein sirf Cash on Delivery (COD) qubool kartay hain taake ap itmenan se parcel wasool karnay par raqam ada kar sakein.";
    }
    return "We currently offer nationwide Cash on Delivery (COD) across Pakistan. You pay the courier in cash upon receiving and inspecting your parcel.";
  }

  // 7. Classification: Returns & Exchange Policy
  if (hasAnyWord(text, ['return', 'exchange', 'wapsi', 'badalna', 'refund', 'policy'])) {
    if (roman) {
      return "AC CLOTHING 7 din ki asan return aur exchange policy faraham karta hai. Agar size ya piece mein masla ho toh unstitched/unworn halat mein exchange karwaya ja sakta hai. Helpline: +92 42 3578 9900.";
    }
    return "We offer a 7-day hassle-free exchange policy. Products must be unstitched, unworn, with original tags intact. Contact our concierge at +92 42 3578 9900 or concierge@acclothing.pk for assistance.";
  }

  // 8. Classification: Coupons & Discounts
  if (hasAnyWord(text, ['coupon', 'discount', 'code', 'offer', 'sale', 'voucher'])) {
    const list = coupons.filter(c => c.isActive).map(c => `**${c.code}** (${c.discountType === 'percent' ? c.discountValue + '%' : 'Rs. ' + c.discountValue} off)`).join(', ');
    if (roman) {
      return `AC CLOTHING ke active discount coupons ye hain: ${list}. Checkout par code darj kar ke faida uthayein!`;
    }
    return `Our current active promo coupons are: ${list}. Enter the code during checkout to claim your discount.`;
  }

  // 9. Classification: Budget inquiries (e.g. "under 6000", "5000 budget")
  const budgetMatch = text.match(/(?:under|below|less than|kam|tak|budget)\s*(?:rs\.?|pkr)?\s*(\d{3,6})/i)
    || text.match(/(\d{3,6})\s*(?:tak|budget|under)/i);

  let budgetLimit = budgetMatch ? parseInt(budgetMatch[1], 10) : null;

  // 10. Filter products by category/fabric/budget
  let matching = [...products];

  if (budgetLimit) {
    matching = matching.filter(p => p.price <= budgetLimit);
  }

  if (hasWord(text, 'lawn')) {
    matching = matching.filter(p => p.fabric.toLowerCase() === 'lawn' || p.category === 'unstitched-lawn');
  } else if (hasWord(text, 'pret') || hasWord(text, 'stitched')) {
    matching = matching.filter(p => p.category === 'ready-to-wear-pret');
  } else if (hasWord(text, 'chiffon') || hasWord(text, 'formal') || hasWord(text, 'wedding')) {
    matching = matching.filter(p => p.category === 'luxury-chiffon-formals' || p.fabric.toLowerCase() === 'chiffon');
  } else if (hasWord(text, 'men') || hasWord(text, 'mens') || hasWord(text, 'kurta') || hasWord(text, 'boski')) {
    matching = matching.filter(p => p.gender === 'men' || p.category === 'mens-kurta-shalwar-kameez');
  } else if (hasWord(text, 'khaddar') || hasWord(text, 'winter')) {
    matching = matching.filter(p => p.category === 'winter-khaddar-linen' || p.fabric.toLowerCase() === 'khaddar');
  } else if (hasWord(text, 'velvet')) {
    matching = matching.filter(p => p.category === 'festive-velvet-jacquard' || p.fabric.toLowerCase() === 'velvet');
  } else if (hasWord(text, 'silk')) {
    matching = matching.filter(p => p.fabric.toLowerCase() === 'silk' || p.category === 'embroidered-silk-organza');
  } else if (hasWord(text, 'shawl') || hasWord(text, 'dupatta')) {
    matching = matching.filter(p => p.category === 'dupattas-shawls');
  }

  // Select top 4 items
  const picked = matching.slice(0, 4);

  if (picked.length > 0) {
    const itemsList = picked.map(p => `- **${p.name}** — Rs. ${p.price.toLocaleString()} (${p.stock > 0 ? `${p.stock} in stock` : 'Out of stock'}, Fabric: ${p.fabric})`).join('\n');

    if (roman) {
      return `Yahan hamaray behtareen intikhab hain:\n\n${itemsList}\n\nKya ap in mein se kisi ka size ya fabric care detail janna chahtay hain?`;
    }
    return `Here are our recommended selections:\n\n${itemsList}\n\nWould you like more details on fabric care or sizing for any of these?`;
  }

  // Fallback generic response
  if (roman) {
    return "AC CLOTHING ke pas Unstitched Lawn, Ready-to-Wear Pret, Chiffon Formals aur Men's Kurta collection mojood hai. Ap kis khas collection ya budget ke baray mein daryaft karna chahein gay?";
  }
  return "AC CLOTHING offers premium Unstitched Lawn, Ready-to-Wear Pret, Luxury Chiffon Formals, and Men's Kurtas. Please specify your desired fabric, occasion, or budget so I can recommend the perfect match.";
}

// POST /api/chat — Floating Assistant Endpoint
router.post('/', async (req, res) => {
  try {
    const { message, history = [] } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ success: false, message: 'Message is required.' });
    }

    const userMessage = message.trim();

    // Load full catalogue context from Firebase RTDB
    const products = await getProducts();
    const categories = await getCategories();
    const allCoupons = await getCoupons();
    const coupons = allCoupons.filter(c => c.isActive !== false);
    let settings = await db.get('settings');

    if (!settings) {
      settings = {
        storeName: 'AC CLOTHING',
        tagline: 'Wear Your Style',
        shippingFeeDefault: 250,
        freeShippingThreshold: 5000,
        contactPhone: '+92 42 3578 9900',
        contactEmail: 'concierge@acclothing.pk'
      };
    }

    // Identify provider and key
    const rawKey = process.env.AI_API_KEY || process.env.GEMINI_API_KEY || '';
    let provider = (process.env.AI_PROVIDER || '').toLowerCase();

    // Infer from key prefix if not specified
    if (!provider) {
      if (rawKey.startsWith('gsk_')) provider = 'groq';
      else if (rawKey.startsWith('sk-ant-')) provider = 'anthropic';
      else if (rawKey.startsWith('AIza')) provider = 'gemini';
      else if (rawKey.startsWith('sk-or-')) provider = 'openrouter';
      else if (rawKey.startsWith('sk-')) provider = 'openai';
      else if (rawKey) provider = 'gemini';
      else provider = 'deterministic';
    }

    // Build catalogue summary string for prompt
    const catalogueSummary = products.map(p =>
      `• ${p.name} | Category: ${p.category} | Subcategory: ${p.subcategory || 'General'} | Brand: ${p.brand || 'AC CLOTHING'} | Description/material: ${p.description || 'Ask our team for details'} | Fabric: ${p.fabric || 'See product description'} | Price: Rs. ${Number(p.price).toLocaleString('en-PK')} | Stock: ${p.stock} | Sizes: ${(p.sizes || []).join(', ')} | Colors: ${(p.colors || []).join(', ')} | Image: ${p.image || (p.images || [])[0] || ''} | Product URL: /product.html?slug=${p.slug || p.id}`
    ).join('\\n');

    const couponSummary = coupons.map(c =>
      `• Code: ${c.code} (${c.discountType === 'percent' ? c.discountValue + '%' : 'Rs. ' + c.discountValue} off, Min order: Rs. ${c.minOrderValue})`
    ).join('\n');

    const systemPrompt = `You are "Your Assistant", the luxury fashion concierge for AC CLOTHING ("Wear Your Style"), a high-end Pakistani fashion & fabrics e-commerce house priced in PKR.

STORE INFORMATION:
- Store Name: AC CLOTHING
- Contact: Phone ${settings.contactPhone}, Email ${settings.contactEmail}, Lahore Flagship: 42-MM Alam Road, Gulberg III, Lahore, Pakistan.
- Shipping: Flat Rs. 250 across Pakistan. Free shipping on orders of Rs. 5,000 and above.
- Delivery: 3 to 5 business days via courier.
- Payment: Strictly Cash on Delivery (COD) only nationwide. Online card payments are not yet available.
- Returns/Exchange: 7-day exchange window for unstitched or unworn items with original tags.
- Sizing: Ready-to-wear sizes XS (34" chest), S (36"), M (38"), L (41"), XL (44"). Unstitched suits include 3-meter shirt, 2.5-meter trouser, 2.5-meter dupatta.
- Order Statuses: Pending, Confirmed, Processing, Shipped, Delivered, Cancelled.

ACTIVE COUPONS:
${couponSummary}

FULL PRODUCT CATALOGUE (Live Stock, exact prices, sizes, colors, descriptions and local image paths):
${catalogueSummary}

MANDATORY BEHAVIOUR RULES:
1. Mirror the customer's language exactly: If user writes in Roman Urdu (e.g. "mujhe koi acha lawn suit dikhayein"), reply in natural, polite Roman Urdu. If in English, reply in English.
2. Lead with the direct answer.
3. If mentioning products, list AT MOST 4 items. Use bold item names with exact price and stock: e.g. "**Zahra — 3pc Embroidered Luxury Lawn** — Rs. 8,450 (18 in stock)".
4. NEVER invent products, prices, or stock that are not in the catalogue above.
5. Respect any stated budget (e.g., under Rs. 6,000).
6. Answer questions about fabrics in practical, accurate terms: explain texture, drape, breathability, opacity, season, occasion and care. Clearly distinguish general fabric knowledge from product-specific facts. Never claim a fabric composition unless the catalogue says so.
7. Cover the complete AC CLOTHING range: men's, women's and kids' clothing; shirts, T-shirts, pants/trousers, jeans, belts/accessories, kurta and full shalwar qameez suits, unstitched fabric, lawn, cotton, linen, denim, chiffon, silk, Boski, Nida and other fabrics present in the catalogue. Recommend from actual matching catalogue entries.
8. When recommending a product, include its local image using Markdown syntax ![Product name](/assets/products/category/file.svg) on a separate line, using the exact Image path from catalogue. Do not invent image paths.
9. Understand the intent first:
   - Greetings, "how are you", "who are you", store identity get warm, specific replies.
   - Out of scope queries (weather, cricket/sports, news, politics, coding, general trivia) MUST receive a polite, clear refusal stating you specialize exclusively in AC CLOTHING fashion.
10. Ask at most ONE polite follow-up question.
11. DO NOT use emoji.
12. Keep reasoning crisp and direct.`;

    let reply = null;

    // Try AI Provider if key is configured
    if (rawKey && provider !== 'deterministic') {
      try {
        if (provider === 'gemini') {
          const { GoogleGenAI } = require('@google/genai');
          const ai = new GoogleGenAI({
            apiKey: rawKey,
            httpOptions: {
              headers: {
                'User-Agent': 'aistudio-build'
              }
            }
          });

          const geminiModel = process.env.AI_MODEL || 'gemini-3.8-flash';
          const response = await ai.models.generateContent({
            model: geminiModel,
            contents: `${systemPrompt}\n\nCustomer question: ${userMessage}`,
            config: {
              temperature: 0.4
            }
          });

          if (response && response.text) {
            reply = response.text.trim();
          }
        } else if (provider === 'groq' || provider === 'openai' || provider === 'openrouter') {
          let endpoint = 'https://api.openai.com/v1/chat/completions';
          let defaultModel = 'gpt-4o-mini';

          if (provider === 'groq') {
            endpoint = 'https://api.groq.com/openai/v1/chat/completions';
            defaultModel = 'llama-3.3-70b-versatile';
          } else if (provider === 'openrouter') {
            endpoint = 'https://openrouter.ai/api/v1/chat/completions';
            defaultModel = 'google/gemini-2.5-flash';
          }

          const modelName = process.env.AI_MODEL || defaultModel;

          const fetchRes = await fetch(endpoint, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'Authorization': `Bearer ${rawKey}`
            },
            body: JSON.stringify({
              model: modelName,
              messages: [
                { role: 'system', content: systemPrompt },
                ...history.slice(-6),
                { role: 'user', content: userMessage }
              ],
              temperature: 0.5,
              max_tokens: 800
            })
          });

          if (fetchRes.ok) {
            const data = await fetchRes.json();
            reply = data.choices?.[0]?.message?.content?.trim();
          }
        } else if (provider === 'anthropic') {
          const fetchRes = await fetch('https://api.anthropic.com/v1/messages', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              'x-api-key': rawKey,
              'anthropic-version': '2023-06-01'
            },
            body: JSON.stringify({
              model: process.env.AI_MODEL || 'claude-3-5-sonnet-latest',
              system: systemPrompt,
              messages: [{ role: 'user', content: userMessage }],
              max_tokens: 800
            })
          });

          if (fetchRes.ok) {
            const data = await fetchRes.json();
            reply = data.content?.[0]?.text?.trim();
          }
        }
      } catch (aiErr) {
        console.warn('[AI Assistant] Provider invocation warning, switching to deterministic engine:', aiErr.message);
      }
    }

    // Silent deterministic fallback so chat never dies
    if (!reply) {
      reply = deterministicAnswer(userMessage, products, categories, coupons, settings);
    }

    res.json({
      success: true,
      reply,
      provider: rawKey ? provider : 'deterministic'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
