/**
 * AC CLOTHING — Content, Settings & Newsletter Routes
 * Powered by Firebase Realtime Database.
 */
const express = require('express');
const router = express.Router();
const { db, getReviews } = require('../services/firebase');

// GET /api/content/banners
router.get('/banners', async (req, res) => {
  try {
    const banners = await db.get('banners') || {};
    const list = Object.entries(banners)
      .map(([k, v]) => ({ _id: k, id: k, ...v }))
      .filter(b => b.isActive !== false);
    res.json({ success: true, banners: list });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/content/settings
router.get('/settings', async (req, res) => {
  try {
    let settings = await db.get('settings');
    if (!settings) {
      settings = {
        storeName: 'AC CLOTHING',
        tagline: 'Wear Your Style',
        shippingFeeDefault: 250,
        freeShippingThreshold: 5000,
        contactPhone: '+92 42 3578 9900',
        contactEmail: 'concierge@acclothing.pk',
        contactAddress: 'AC Fashion House, 42-MM Alam Road, Gulberg III, Lahore, Pakistan',
        announcementText: 'Complimentary shipping across Pakistan on all orders over Rs. 5,000 | Cash on Delivery Available',
        currency: 'PKR',
        currencySymbol: 'Rs.'
      };
    }
    res.json({ success: true, settings });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/content/testimonials
router.get('/testimonials', async (req, res) => {
  try {
    const reviews = await getReviews();
    const testimonials = reviews
      .filter(r => r.rating >= 4 && r.isModerated !== false)
      .slice(0, 6);
    res.json({ success: true, testimonials });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/content/newsletter
router.post('/newsletter', async (req, res) => {
  try {
    const { email } = req.body;
    if (!email || !email.includes('@')) {
      return res.status(400).json({ success: false, message: 'Valid email address required.' });
    }

    const cleanEmail = email.toLowerCase().trim();
    const id = cleanEmail.replace(/[^a-z0-9]/g, '_');
    await db.set(`subscribers/${id}`, {
      email: cleanEmail,
      subscribedAt: new Date().toISOString()
    });

    res.json({
      success: true,
      message: 'Thank you for subscribing to AC CLOTHING private dispatches!'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
