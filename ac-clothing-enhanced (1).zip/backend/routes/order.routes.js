/**
 * AC CLOTHING — Orders Processing Layer
 * Powered by Firebase Realtime Database.
 * Supports Cash on Delivery and AC Wallet Balance (Rs. 30,000 store credit).
 */
const express = require('express');
const router = express.Router();
const {
  db,
  getOrders,
  getOrderById,
  createOrder,
  getProductById,
  getUserById
} = require('../services/firebase');
const { protect, optionalAuth } = require('../middleware/auth');

// POST /api/orders — Place new order
router.post('/', optionalAuth, async (req, res) => {
  try {
    const {
      customer,
      items,
      shippingAddress,
      paymentMethod = 'cod',
      couponCode,
      notes
    } = req.body;

    if (!items || !items.length) {
      return res.status(400).json({ success: false, message: 'Cart items are required.' });
    }

    if (!customer || !customer.name || !customer.phone) {
      return res.status(400).json({ success: false, message: 'Customer name and phone number are required.' });
    }

    if (!shippingAddress || !shippingAddress.street || !shippingAddress.city) {
      return res.status(400).json({ success: false, message: 'Complete delivery address is required.' });
    }

    // Server-side calculation & verification
    let subtotal = 0;
    const validatedItems = [];

    for (const item of items) {
      const pId = item.productId || item.id || item._id;
      const product = await getProductById(pId);
      if (!product) {
        return res.status(400).json({
          success: false,
          message: `Product "${item.name || pId}" is no longer available.`
        });
      }

      const qty = Math.max(1, parseInt(item.quantity, 10) || 1);
      if (product.stock < qty) {
        return res.status(400).json({
          success: false,
          message: `Insufficient stock for "${product.name}". Only ${product.stock} available.`
        });
      }

      const itemTotal = (product.price || 0) * qty;
      subtotal += itemTotal;

      validatedItems.push({
        productId: product.id,
        name: product.name,
        price: product.price,
        quantity: qty,
        size: item.size || 'Standard',
        color: item.color || '',
        image: product.image || (product.images && product.images[0]) || ''
      });
    }

    const shippingFee = subtotal >= 5000 ? 0 : 250;
    let discountAmount = 0;

    if (couponCode) {
      const coupons = await db.get('coupons');
      if (coupons) {
        for (const [k, c] of Object.entries(coupons)) {
          if (c.code && c.code.toUpperCase() === couponCode.toUpperCase().trim() && c.isActive) {
            if (!c.minOrderValue || subtotal >= c.minOrderValue) {
              if (c.discountType === 'percentage') {
                discountAmount = Math.round((subtotal * c.discountValue) / 100);
              } else {
                discountAmount = Math.min(subtotal, c.discountValue);
              }
            }
          }
        }
      }
    }

    const totalAmount = Math.max(0, subtotal - discountAmount + shippingFee);

    // If payment method is wallet, check user's balance
    const userId = req.user ? (req.user.uid || req.user.id) : (customer.uid || null);
    if (paymentMethod === 'wallet') {
      if (!userId) {
        return res.status(401).json({
          success: false,
          message: 'Please sign in to your AC Clothing account to pay with wallet credit.'
        });
      }

      const user = await getUserById(userId);
      const curBalance = user ? (Number(user.walletBalance) || 0) : 0;

      if (curBalance < totalAmount) {
        return res.status(400).json({
          success: false,
          message: `Insufficient AC Wallet balance. Your balance is Rs. ${curBalance.toLocaleString('en-PK')}, but order total is Rs. ${totalAmount.toLocaleString('en-PK')}.`
        });
      }
    }

    const newOrder = await createOrder({
      userId,
      customer: {
        name: customer.name,
        email: customer.email || '',
        phone: customer.phone
      },
      shippingAddress: {
        street: shippingAddress.street,
        city: shippingAddress.city,
        postalCode: shippingAddress.postalCode || '',
        label: shippingAddress.label || 'Home'
      },
      items: validatedItems,
      subtotal,
      discountAmount,
      shippingFee,
      totalAmount,
      couponCode: couponCode || null,
      paymentMethod, // 'wallet' or 'cod'
      paymentStatus: paymentMethod === 'wallet' ? 'Paid (Store Credit)' : 'Pending (COD)',
      notes: notes || '',
      status: 'Pending',
      createdAt: new Date().toISOString()
    });

    res.status(201).json({
      success: true,
      order: newOrder,
      orderNumber: newOrder.orderNumber,
      message: paymentMethod === 'wallet'
        ? `Order #${newOrder.orderNumber} confirmed! Paid using AC Store Credit.`
        : `Order #${newOrder.orderNumber} placed successfully with Cash on Delivery!`
    });
  } catch (err) {
    console.error('Order creation error:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/orders/user/me & /api/orders/my-orders — Current customer orders
const getUserOrdersHandler = async (req, res) => {
  try {
    const uid = req.user.uid || req.user.id;
    const allOrders = await getOrders();
    const userOrders = allOrders.filter(o => o.userId === uid || (o.customer && o.customer.email === req.user.email));

    res.json({
      success: true,
      orders: userOrders
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
};

router.get('/user/me', protect, getUserOrdersHandler);
router.get('/my-orders', protect, getUserOrdersHandler);

// GET /api/orders/:orderNumber — Order status tracking
router.get('/:orderNumber', async (req, res) => {
  try {
    const { orderNumber } = req.params;
    const order = await getOrderById(orderNumber);

    if (!order) {
      return res.status(404).json({ success: false, message: `Order #${orderNumber} not found.` });
    }

    res.json({
      success: true,
      order
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/orders/:orderNumber/cancel — Cancel order & restore wallet/stock
router.post('/:orderNumber/cancel', protect, async (req, res) => {
  try {
    const { orderNumber } = req.params;
    const order = await getOrderById(orderNumber);

    if (!order) {
      return res.status(404).json({ success: false, message: 'Order not found' });
    }

    const uid = req.user.uid || req.user.id;
    const isOwner = order.userId === uid || (order.customer && order.customer.email === req.user.email);
    const isAdmin = req.user.role === 'admin';

    if (!isOwner && !isAdmin) {
      return res.status(403).json({ success: false, message: 'Unauthorized to cancel this order.' });
    }

    if (order.status === 'Cancelled') {
      return res.status(400).json({ success: false, message: 'This order has already been cancelled.' });
    }

    if (order.status === 'Shipped' || order.status === 'Delivered') {
      return res.status(400).json({ success: false, message: 'Orders that have already shipped cannot be cancelled online.' });
    }

    // 1. Mark order cancelled in Firebase RTDB
    await db.update(`orders/${order.id}`, {
      status: 'Cancelled',
      cancelledAt: new Date().toISOString()
    });

    // 2. Restore stock for items
    if (Array.isArray(order.items)) {
      for (const item of order.items) {
        const pId = item.productId || item.id;
        if (pId) {
          try {
            const product = await getProductById(pId);
            if (product) {
              await db.update(`products/${product.id}`, {
                stock: (product.stock || 0) + (item.quantity || 1),
                soldCount: Math.max(0, (product.soldCount || 0) - (item.quantity || 1))
              });
            }
          } catch (e) {}
        }
      }
    }

    // 3. Refund wallet balance if paid with wallet
    if (order.paymentMethod === 'wallet' && order.userId) {
      const user = await getUserById(order.userId);
      if (user) {
        const refundAmount = Number(order.totalAmount || 0);
        const newBalance = (Number(user.walletBalance) || 0) + refundAmount;
        await db.update(`users/${order.userId}`, { walletBalance: newBalance });

        // Record refund transaction
        await db.push(`transactions/${order.userId}`, {
          type: 'CREDIT',
          amount: refundAmount,
          orderId: order.orderNumber,
          description: `Refund for Cancelled Order #${order.orderNumber}`,
          balanceAfter: newBalance,
          date: new Date().toISOString()
        });
      }
    }

    res.json({
      success: true,
      message: `Order #${order.orderNumber} was cancelled and stock has been restored.`
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
