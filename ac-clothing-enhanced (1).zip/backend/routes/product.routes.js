/**
 * AC CLOTHING — Products & Categories Public Routes
 * Powered by Firebase Realtime Database.
 */
const express = require('express');
const router = express.Router();
const {
  getProducts,
  getProductById,
  getCategories,
  getReviews
} = require('../services/firebase');

// GET /api/products — filtered, searched, sorted & paginated catalog
router.get('/products', async (req, res) => {
  try {
    const {
      search,
      category,
      gender,
      sizes,
      colors,
      fabric,
      availability,
      minPrice,
      maxPrice,
      sort,
      page = 1,
      limit = 12,
      new: isNew
    } = req.query;

    let products = await getProducts();

    // 1. Search term (case-insensitive substring across name, description, fabric, category)
    if (search && search.trim()) {
      const q = search.trim().toLowerCase();
      products = products.filter(p =>
        (p.name && p.name.toLowerCase().includes(q)) ||
        (p.description && p.description.toLowerCase().includes(q)) ||
        (p.fabric && p.fabric.toLowerCase().includes(q)) ||
        (p.category && p.category.toLowerCase().includes(q)) ||
        (p.subcategory && p.subcategory.toLowerCase().includes(q))
      );
    }

    // 2. Category filter
    if (category && category !== 'all') {
      const catList = category.split(',').map(c => c.trim().toLowerCase());
      products = products.filter(p => {
        const cat = (p.category || '').toLowerCase();
        const sub = (p.subcategory || '').toLowerCase();
        const slug = (p.categorySlug || '').toLowerCase();
        return catList.some(c => cat.includes(c) || sub.includes(c) || slug === c);
      });
    }

    // 3. Gender filter
    if (gender && gender !== 'all') {
      const g = gender.toLowerCase();
      products = products.filter(p => (p.gender || '').toLowerCase() === g);
    }

    // 4. Fabric filter
    if (fabric && fabric !== 'all') {
      const fabList = fabric.split(',').map(f => f.trim().toLowerCase());
      products = products.filter(p => fabList.some(f => (p.fabric || '').toLowerCase().includes(f)));
    }

    // 5. Size filter
    if (sizes && sizes !== 'all') {
      const sizeList = sizes.split(',').map(s => s.trim().toUpperCase());
      products = products.filter(p => {
        if (!Array.isArray(p.sizes)) return false;
        return p.sizes.some(s => sizeList.includes(s.toUpperCase()));
      });
    }

    // 6. Colors filter
    if (colors && colors !== 'all') {
      const colList = colors.split(',').map(c => c.trim().toLowerCase());
      products = products.filter(p => {
        if (!Array.isArray(p.colors)) return false;
        return p.colors.some(c => colList.includes(c.toLowerCase()));
      });
    }

    // 7. Availability filter
    if (availability === 'in-stock') {
      products = products.filter(p => Number(p.stock) > 0);
    } else if (availability === 'out-of-stock') {
      products = products.filter(p => Number(p.stock) <= 0);
    }

    // 8. Price bounds
    if (minPrice) {
      products = products.filter(p => p.price >= Number(minPrice));
    }
    if (maxPrice) {
      products = products.filter(p => p.price <= Number(maxPrice));
    }

    // 9. New arrivals tag
    if (isNew === 'true') {
      products = products.filter(p => p.isNew || p.isNewArrival);
    }

    // 10. Sorting
    switch (sort) {
      case 'price-asc':
        products.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        products.sort((a, b) => b.price - a.price);
        break;
      case 'newest':
        products.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
        break;
      case 'popular':
      default:
        products.sort((a, b) => (b.soldCount || 0) - (a.soldCount || 0));
        break;
    }

    // Compute Facets dynamically
    const allProducts = await getProducts();
    const allFabrics = Array.from(new Set(allProducts.map(p => p.fabric).filter(Boolean)));
    const allSizes = Array.from(new Set(allProducts.flatMap(p => p.sizes || []).filter(Boolean)));
    const allColors = Array.from(new Set(allProducts.flatMap(p => p.colors || []).filter(Boolean)));

    // Pagination
    const total = products.length;
    const pNum = Math.max(1, parseInt(page, 10));
    const pLimit = Math.max(1, parseInt(limit, 10));
    const startIndex = (pNum - 1) * pLimit;
    const paginatedProducts = products.slice(startIndex, startIndex + pLimit);

    res.json({
      success: true,
      products: paginatedProducts,
      meta: {
        total,
        page: pNum,
        limit: pLimit,
        totalPages: Math.ceil(total / pLimit),
        hasNext: startIndex + pLimit < total,
        hasPrev: pNum > 1
      },
      facets: {
        fabrics: allFabrics,
        sizes: allSizes,
        colors: allColors
      }
    });
  } catch (err) {
    console.error('Error fetching products:', err);
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/categories
router.get('/categories', async (req, res) => {
  try {
    const categories = await getCategories();
    res.json({ success: true, categories });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// GET /api/products/:idOrSlug
router.get('/products/:idOrSlug', async (req, res) => {
  try {
    const { idOrSlug } = req.params;
    const product = await getProductById(idOrSlug);

    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    // Get related products from same category
    const all = await getProducts();
    const related = all
      .filter(p => p.id !== product.id && p.category === product.category)
      .slice(0, 4);

    res.json({
      success: true,
      product,
      related
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
