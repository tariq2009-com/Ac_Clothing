/**
 * AC CLOTHING — Reviews Routes
 * Powered by Firebase Realtime Database.
 */
const express = require('express');
const router = express.Router();
const { db, getProductById, getReviews } = require('../services/firebase');
const { protect } = require('../middleware/auth');

// GET /api/reviews/:productId
router.get('/:productId', async (req, res) => {
  try {
    const { productId } = req.params;
    const all = await getReviews();
    const reviews = all.filter(r => (r.productId === productId) && r.isModerated !== false);
    reviews.sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
    res.json({ success: true, reviews });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/reviews — Submit review
router.post('/', protect, async (req, res) => {
  try {
    const { productId, rating, comment } = req.body;
    if (!productId || !rating || !comment) {
      return res.status(400).json({
        success: false,
        message: 'Product ID, rating (1-5), and review comment are required.'
      });
    }

    const product = await getProductById(productId);
    if (!product) {
      return res.status(404).json({ success: false, message: 'Product not found.' });
    }

    const revId = `rev-${Date.now()}`;
    const review = {
      id: revId,
      _id: revId,
      productId: product.id,
      userId: req.user.uid || req.user.id || req.user._id,
      userName: req.user.name,
      rating: Math.min(5, Math.max(1, parseInt(rating, 10) || 5)),
      comment: comment.trim(),
      isModerated: true,
      createdAt: new Date().toISOString()
    };

    await db.set(`reviews/${revId}`, review);

    res.status(201).json({
      success: true,
      review,
      message: 'Thank you! Your review has been submitted.'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
