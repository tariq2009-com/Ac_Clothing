/**
 * AC CLOTHING — Wishlist Routes
 * Powered by Firebase Realtime Database.
 */
const express = require('express');
const router = express.Router();
const { db, getProductById } = require('../services/firebase');
const { protect } = require('../middleware/auth');

// GET /api/wishlist
router.get('/', protect, async (req, res) => {
  try {
    const uid = req.user.uid || req.user.id || req.user._id;
    const wishlistData = await db.get(`wishlists/${uid}`) || [];
    const productIds = Array.isArray(wishlistData) ? wishlistData : Object.keys(wishlistData);

    const productList = [];
    for (const prodId of productIds) {
      const p = await getProductById(prodId);
      if (p) productList.push(p);
    }

    res.json({
      success: true,
      wishlist: productList,
      count: productList.length
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

// POST /api/wishlist/toggle
router.post('/toggle', protect, async (req, res) => {
  try {
    const { productId } = req.body;
    if (!productId) {
      return res.status(400).json({ success: false, message: 'Product ID is required.' });
    }

    const uid = req.user.uid || req.user.id || req.user._id;
    const wishlistData = await db.get(`wishlists/${uid}`) || [];
    let products = Array.isArray(wishlistData) ? wishlistData : Object.keys(wishlistData);

    const index = products.indexOf(productId);
    let added = false;

    if (index > -1) {
      products.splice(index, 1);
    } else {
      products.push(productId);
      added = true;
    }

    await db.set(`wishlists/${uid}`, products);

    res.json({
      success: true,
      added,
      count: products.length,
      message: added ? 'Item added to wishlist' : 'Item removed from wishlist'
    });
  } catch (err) {
    res.status(500).json({ success: false, message: err.message });
  }
});

module.exports = router;
