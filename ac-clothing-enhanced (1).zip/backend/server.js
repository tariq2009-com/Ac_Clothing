/**
 * AC CLOTHING — Express Application Entry Point
 * Designed for both standard Node.js server (node server.js)
 * and Netlify Serverless Function wrapper.
 */
require('dotenv').config({ path: require('path').join(__dirname, '..', '.env') });
const path = require('path');
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const cookieParser = require('cookie-parser');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const { seedDatabase } = require('./services/seed');

const authRoutes = require('./routes/auth.routes');
const productRoutes = require('./routes/product.routes');
const cartRoutes = require('./routes/cart.routes');
const orderRoutes = require('./routes/order.routes');
const wishlistRoutes = require('./routes/wishlist.routes');
const reviewRoutes = require('./routes/review.routes');
const contentRoutes = require('./routes/content.routes');
const adminRoutes = require('./routes/admin.routes');
const chatRoutes = require('./routes/chat.routes');

const app = express();

// Trust reverse proxy (Cloud Run, Nginx, AI Studio proxy)
app.set('trust proxy', 1);

// Safe Buffer Parsing Hook for Serverless / Netlify
app.use((req, res, next) => {
  if (Buffer.isBuffer(req.body)) {
    try {
      const str = req.body.toString('utf8');
      if (str && str.trim()) {
        req.body = JSON.parse(str);
      } else {
        req.body = {};
      }
    } catch {
      // If parsing fails, proceed without crashing
    }
  }
  next();
});

// Middleware setup
app.use(helmet({
  contentSecurityPolicy: false, // Allows flexible inline SVGs and self-hosted images
  crossOriginEmbedderPolicy: false
}));
app.use(cors({
  origin: true,
  credentials: true
}));
app.use(compression());
app.use(cookieParser());
app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));

// Standard body parsers
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true, limit: '10mb' }));

// General Rate limiter configured for proxy environments (disable false validation alarms)
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 600,
  standardHeaders: true,
  legacyHeaders: false,
  validate: false,
  keyGenerator: (req) => {
    return req.ip || req.headers['x-forwarded-for'] || req.socket.remoteAddress || '127.0.0.1';
  },
  message: { success: false, message: 'Too many requests. Please try again shortly.' }
});
app.use('/api', limiter);

// Guarded Auto-Seed Hook for Firebase RTDB
let isSeeded = false;
async function ensureSeeded() {
  if (!isSeeded) {
    await seedDatabase(false);
    isSeeded = true;
  }
}

app.use(async (req, res, next) => {
  if (!isSeeded) {
    try {
      await ensureSeeded();
    } catch (err) {
      console.error('[Firebase Database] Seeding check error:', err);
    }
  }
  next();
});

// Mount API routes
app.use('/api/auth', authRoutes);
app.use('/api', productRoutes);
app.use('/api/cart', cartRoutes);
app.use('/api/orders', orderRoutes);
app.use('/api/wishlist', wishlistRoutes);
app.use('/api/reviews', reviewRoutes);
app.use('/api/content', contentRoutes);
app.use('/api/admin', adminRoutes);
app.use('/api/chat', chatRoutes);

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    store: 'AC CLOTHING',
    timestamp: new Date().toISOString()
  });
});

// Serve frontend static assets
const frontendDir = path.resolve(__dirname, '..', 'frontend');
app.use(express.static(frontendDir));

// Clean URL routing for the 17 storefront pages + admin
const pages = [
  'shop', 'product', 'cart', 'checkout', 'order-confirmation',
  'track', 'account', 'login', 'register', 'forgot-password',
  'wishlist', 'about', 'contact', 'policies', '404', 'auth-check'
];

pages.forEach(page => {
  app.get(`/${page}`, (req, res) => {
    res.sendFile(path.join(frontendDir, `${page}.html`));
  });
});

app.get('/admin', (req, res) => {
  res.sendFile(path.join(frontendDir, 'admin', 'index.html'));
});
app.get('/admin/*', (req, res) => {
  res.sendFile(path.join(frontendDir, 'admin', 'index.html'));
});

// Root route
app.get('/', (req, res) => {
  res.sendFile(path.join(frontendDir, 'index.html'));
});

// 404 Handler for undefined API routes
app.use('/api/*', (req, res) => {
  res.status(404).json({ success: false, message: 'API route not found' });
});

// 404 Handler for general web pages
app.use((req, res) => {
  res.status(404).sendFile(path.join(frontendDir, '404.html'));
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('[Server Error]', err);
  res.status(err.status || 500).json({
    success: false,
    message: err.message || 'Internal Server Error'
  });
});

// Server Starter
async function start(port = process.env.PORT || 3000) {
  await ensureSeeded();
  return new Promise((resolve) => {
    const server = app.listen(port, '0.0.0.0', () => {
      console.log(`[AC CLOTHING] Server operational on http://0.0.0.0:${port}`);
      resolve(server);
    });
  });
}

// Only listen if executed directly
if (require.main === module) {
  start();
}

module.exports = {
  app,
  start
};
