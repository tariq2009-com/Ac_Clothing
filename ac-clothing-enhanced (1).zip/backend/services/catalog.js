/**
 * AC CLOTHING — Firebase Product & Category Seed Service
 * Seeds Firebase Realtime Database with 23 products and multi-level categories.
 */

const { db } = require('./firebase');

const INITIAL_CATEGORIES = {
  'mens-collection': {
    name: "Men's Collection",
    slug: 'mens-collection',
    gender: 'men',
    description: "Premium Men's T-Shirts, Formal Shirts, Trousers, Denim Jeans, and Royal Boski Shalwar Qameez.",
    image: '/assets/products/men/men-collection.svg'
  },
  'womens-collection': {
    name: "Women's Collection",
    slug: 'womens-collection',
    gender: 'women',
    description: "Exquisite embroidered Swiss lawn, festive chiffon dresses, linen tunics, and modest abayas.",
    image: '/assets/products/women/women-collection.svg'
  },
  'kids-collection': {
    name: "Kids Collection",
    slug: 'kids-collection',
    gender: 'kids',
    description: 'Charming festive kurta sets, graphic cotton tees, plaid shirts, and comfortable pants for boys and girls.',
    image: '/assets/products/kids/kids-collection.svg'
  },
  'fabrics': {
    name: 'Fabrics',
    slug: 'fabrics',
    gender: 'fabrics',
    description: 'Authentic 4.5m men’s Latha cotton and pure 3m women’s raw silk unstitched fabrics.',
    image: '/assets/products/fabrics/fabrics-collection.svg'
  },
  'accessories': {
    name: 'Accessories',
    slug: 'accessories',
    gender: 'accessories',
    description: 'Handcrafted full-grain leather belts, engraved cufflinks, and bespoke wardrobe accessories.',
    image: '/assets/products/accessories/accessories-collection.svg'
  }
};

const INITIAL_PRODUCTS = {
  'prod-m-1': {
    id: 'prod-m-1',
    name: "Men's Classic Pique Polo T-Shirt",
    category: "Men's Collection",
    subcategory: "Men's T-Shirts",
    brand: 'AC Urban',
    gender: 'men',
    price: 2450,
    stock: 25,
    soldCount: 8,
    isNew: true,
    description: 'Crafted from breathable 100% combed cotton pique with a structured knit collar, two-button placket, and ribbed cuffs. Designed for versatile casual or smart-casual styling.',
    colors: ['Navy Blue', 'White', 'Black'],
    sizes: ['S', 'M', 'L', 'XL'],
    image: '/assets/products/men/polo-tee.svg',
    images: ['/assets/products/men/polo-tee.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-m-2': {
    id: 'prod-m-2',
    name: "Men's Premium Cotton Crewneck Tee",
    category: "Men's Collection",
    subcategory: "Men's T-Shirts",
    brand: 'AC Basics',
    gender: 'men',
    price: 1850,
    stock: 30,
    soldCount: 15,
    isNew: false,
    description: 'Ultra-soft, ring-spun jersey cotton crewneck T-shirt with reinforced double-needle stitching. Retains shape and soft hand-feel after every wash.',
    colors: ['Heather Grey', 'Olive Green', 'Maroon'],
    sizes: ['M', 'L', 'XL'],
    image: '/assets/products/men/crewneck-tee.svg',
    images: ['/assets/products/men/crewneck-tee.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-m-3': {
    id: 'prod-m-3',
    name: "Men's Oxford Button-Down Formal Shirt",
    category: "Men's Collection",
    subcategory: "Men's Shirts",
    brand: 'AC Formal',
    gender: 'men',
    price: 3650,
    stock: 20,
    soldCount: 12,
    isNew: true,
    description: 'Tailored from heavyweight pure Oxford weave cotton. Features an authentic button-down collar, chest pocket, and mother-of-pearl buttons.',
    colors: ['Sky Blue', 'Crisp White'],
    sizes: ['S', 'M', 'L', 'XL'],
    image: '/assets/products/men/oxford-shirt.svg',
    images: ['/assets/products/men/oxford-shirt.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-m-4': {
    id: 'prod-m-4',
    name: "Men's Casual Linen Blend Shirt",
    category: "Men's Collection",
    subcategory: "Men's Shirts",
    brand: 'AC Summer',
    gender: 'men',
    price: 3250,
    stock: 18,
    soldCount: 6,
    isNew: false,
    description: 'Breathable linen-cotton blend shirt tailored in a relaxed fit with mandarin band collar. Perfect for warm Sindh and Punjab afternoons.',
    colors: ['Natural Beige', 'Mint Green'],
    sizes: ['M', 'L', 'XL'],
    image: '/assets/products/men/linen-shirt.svg',
    images: ['/assets/products/men/linen-shirt.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-m-5': {
    id: 'prod-m-5',
    name: "Men's Tailored Chino Trousers",
    category: "Men's Collection",
    subcategory: "Men's Pants",
    brand: 'AC Sartorial',
    gender: 'men',
    price: 3850,
    stock: 22,
    soldCount: 14,
    isNew: false,
    description: 'Flat-front slim-straight chinos cut from 98% cotton twill with 2% elastane for effortless all-day stretch and motion.',
    colors: ['Khaki', 'Charcoal Grey', 'Navy'],
    sizes: ['30', '32', '34', '36'],
    image: '/assets/products/men/chino-pants.svg',
    images: ['/assets/products/men/chino-pants.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-m-6': {
    id: 'prod-m-6',
    name: "Men's Slim-Fit Raw Indigo Denim Jeans",
    category: "Men's Collection",
    subcategory: "Men's Jeans",
    brand: 'AC Denim',
    gender: 'men',
    price: 4200,
    stock: 20,
    soldCount: 9,
    isNew: true,
    description: '13oz sturdy indigo selvedge-inspired denim woven with authentic ring-spun yarn. Features copper hardware and classic five-pocket styling.',
    colors: ['Dark Indigo', 'Washed Blue'],
    sizes: ['30', '32', '34', '36'],
    image: '/assets/products/men/denim-jeans.svg',
    images: ['/assets/products/men/denim-jeans.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-m-7': {
    id: 'prod-m-7',
    name: "Men's Royal Spun Boski Shalwar Qameez",
    category: "Men's Collection",
    subcategory: "Men's Shalwar Qameez",
    brand: 'AC Heritage',
    gender: 'men',
    price: 8950,
    stock: 15,
    soldCount: 22,
    isNew: true,
    description: 'Impeccable traditional 2-piece suite crafted from heavy 8-pound weight spun Boski silk with tailored ban collar, French cuffs, and authentic mother-of-pearl buttons.',
    colors: ['Warm Cream Boski', 'Optic White'],
    sizes: ['S', 'M', 'L', 'XL'],
    image: '/assets/products/men/boski-suit.svg',
    images: ['/assets/products/men/boski-suit.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-m-8': {
    id: 'prod-m-8',
    name: "Men's Egyptian Giza Cotton Kurta",
    category: "Men's Collection",
    subcategory: "Men's Shalwar Qameez",
    brand: 'AC Heritage',
    gender: 'men',
    price: 4650,
    stock: 24,
    soldCount: 18,
    isNew: false,
    description: 'Stitched from 100% extra-long staple Egyptian Giza cotton with subtle tone-on-tone embroidery along the front placket.',
    colors: ['Charcoal Black', 'Slate Grey'],
    sizes: ['S', 'M', 'L', 'XL'],
    image: '/assets/products/men/cotton-kurta.svg',
    images: ['/assets/products/men/cotton-kurta.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-m-9': {
    id: 'prod-m-9',
    name: "Men's Unstitched Premium Latha Fabric (4.5m)",
    category: 'Fabrics',
    subcategory: "Men's Fabrics",
    brand: 'AC Mill',
    gender: 'fabrics',
    price: 4950,
    stock: 35,
    soldCount: 30,
    isNew: true,
    description: 'Authentic 4.5-meter pure Egyptian combed cotton Latha cloth. Crisp finish that softens luxuriously with every wash. Guaranteed shrinkage-free.',
    colors: ['Pearl White', 'Ivory Cream'],
    sizes: ['4.5 Meters'],
    image: '/assets/products/fabrics/men-latha.svg',
    images: ['/assets/products/fabrics/men-latha.svg'],
    createdAt: new Date().toISOString()
  },

  // Women's Collection
  'prod-w-1': {
    id: 'prod-w-1',
    name: "Women's Embroidered Swiss Lawn 3pc Suit",
    category: "Women's Collection",
    subcategory: "Women's Shalwar Qameez",
    brand: 'AC Festive',
    gender: 'women',
    price: 8450,
    stock: 18,
    soldCount: 26,
    isNew: true,
    description: 'Exquisite 3-piece luxury lawn ensemble featuring intricate floral chikankari front, dyed cambric trouser, and a printed pure silk-chiffon dupatta.',
    colors: ['Sage Green', 'Blush Pink'],
    sizes: ['Unstitched', 'S', 'M', 'L'],
    image: '/assets/products/women/lawn-suit.svg',
    images: ['/assets/products/women/lawn-suit.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-w-2': {
    id: 'prod-w-2',
    name: "Women's Chikankari Summer Lawn Suit",
    category: "Women's Collection",
    subcategory: "Women's Shalwar Qameez",
    brand: 'AC Festive',
    gender: 'women',
    price: 7200,
    stock: 16,
    soldCount: 19,
    isNew: false,
    description: 'All-over delicate Chikankari threadwork on pure Pima lawn. Includes an embroidered organza daman border and a soft voil dupatta.',
    colors: ['Dusty Peach', 'Fresh Mint'],
    sizes: ['Unstitched', 'S', 'M', 'L'],
    image: '/assets/products/women/chikan-suit.svg',
    images: ['/assets/products/women/chikan-suit.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-w-3': {
    id: 'prod-w-3',
    name: "Women's Regal Chiffon Festive Peshwas Dress",
    category: "Women's Collection",
    subcategory: "Women's Dresses",
    brand: 'AC Couture',
    gender: 'women',
    price: 16500,
    stock: 10,
    soldCount: 7,
    isNew: true,
    description: 'Opulent floor-length festive peshwas on pure sheer chiffon, enriched with antique zardozi, sitara, and golden tilla embroidery. Includes matching churidar and organza dupatta.',
    colors: ['Antique Gold', 'Crimson Wine'],
    sizes: ['S', 'M', 'L'],
    image: '/assets/products/women/peshwas-dress.svg',
    images: ['/assets/products/women/peshwas-dress.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-w-4': {
    id: 'prod-w-4',
    name: "Women's Floral Tiered Maxi Dress",
    category: "Women's Collection",
    subcategory: "Women's Dresses",
    brand: 'AC Pret',
    gender: 'women',
    price: 5800,
    stock: 14,
    soldCount: 11,
    isNew: false,
    description: 'Flattering tiered A-line maxi dress in breathable cotton cambric with artisanal botanical block print motifs and elasticated puff sleeves.',
    colors: ['Lavender Floral', 'Teal Botanical'],
    sizes: ['S', 'M', 'L'],
    image: '/assets/products/women/maxi-dress.svg',
    images: ['/assets/products/women/maxi-dress.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-w-5': {
    id: 'prod-w-5',
    name: "Women's Relaxed Fit Cotton Linen Tunic Top",
    category: "Women's Collection",
    subcategory: "Women's T-Shirts/Tops",
    brand: 'AC Casuals',
    gender: 'women',
    price: 2850,
    stock: 22,
    soldCount: 16,
    isNew: true,
    description: 'Modern loose-fit tunic top with drop shoulders, embroidered sleeve hems, and side slits. Pairs effortlessly with culottes or denim.',
    colors: ['Terracotta Coral', 'Off-White'],
    sizes: ['XS', 'S', 'M', 'L'],
    image: '/assets/products/women/tunic-top.svg',
    images: ['/assets/products/women/tunic-top.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-w-6': {
    id: 'prod-w-6',
    name: "Women's Pure Raw Silk Unstitched Fabric (3m)",
    category: 'Fabrics',
    subcategory: "Women's Fabrics",
    brand: 'AC Mill',
    gender: 'fabrics',
    price: 6800,
    stock: 20,
    soldCount: 13,
    isNew: false,
    description: 'Luminous 80gm pure raw silk fabric featuring high tensile strength and rich subcontinental sheen. Suitable for shirts, capes, and formal trousers.',
    colors: ['Emerald Green', 'Royal Sapphire'],
    sizes: ['3 Meters'],
    image: '/assets/products/fabrics/silk-fabric.svg',
    images: ['/assets/products/fabrics/silk-fabric.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-w-7': {
    id: 'prod-w-7',
    name: "Women's Premium Nida Modest Flare Abaya",
    category: "Women's Collection",
    subcategory: "Women's Abayas",
    brand: 'AC Modest',
    gender: 'women',
    price: 7950,
    stock: 12,
    soldCount: 10,
    isNew: true,
    description: 'Crafted from premium Korean Nida fabric known for its graceful drape and opaque coverage. Accented with subtle pleating and matching chiffon hijab.',
    colors: ['Jet Black', 'Espresso Brown'],
    sizes: ['52', '54', '56'],
    image: '/assets/products/women/abaya.svg',
    images: ['/assets/products/women/abaya.svg'],
    createdAt: new Date().toISOString()
  },

  // Kids Collection
  'prod-k-1': {
    id: 'prod-k-1',
    name: 'Boys Casual Graphic Cotton T-Shirt',
    category: 'Kids Collection',
    subcategory: 'Kids T-Shirts',
    brand: 'AC Juniors',
    gender: 'kids',
    price: 1250,
    stock: 28,
    soldCount: 20,
    isNew: true,
    description: 'Pure bio-washed 100% cotton T-shirt featuring playful screen-printed adventure graphics. Gentle on young skin and resilient for playground play.',
    colors: ['Royal Blue', 'Bright Yellow'],
    sizes: ['4-5Y', '6-7Y', '8-9Y'],
    image: '/assets/products/kids/boy-tee.svg',
    images: ['/assets/products/kids/boy-tee.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-k-2': {
    id: 'prod-k-2',
    name: 'Boys Classic Plaid Casual Shirt',
    category: 'Kids Collection',
    subcategory: 'Kids Shirts',
    brand: 'AC Juniors',
    gender: 'kids',
    price: 1950,
    stock: 20,
    soldCount: 8,
    isNew: false,
    description: 'Crisp woven yarn-dyed cotton plaid shirt with curved hem and chest pocket. Perfect for family gatherings and weekend outings.',
    colors: ['Red Plaid', 'Navy Plaid'],
    sizes: ['5-6Y', '7-8Y', '9-10Y'],
    image: '/assets/products/kids/boy-shirt.svg',
    images: ['/assets/products/kids/boy-shirt.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-k-3': {
    id: 'prod-k-3',
    name: 'Boys Elastic-Waist Comfort Cotton Pants',
    category: 'Kids Collection',
    subcategory: 'Kids Pants',
    brand: 'AC Juniors',
    gender: 'kids',
    price: 1850,
    stock: 22,
    soldCount: 14,
    isNew: false,
    description: 'Durable stretch cotton twill pants with an adjustable drawstring waistband and deep utility pockets for daily comfort.',
    colors: ['Khaki', 'Denim Blue'],
    sizes: ['4-5Y', '6-7Y', '8-9Y'],
    image: '/assets/products/kids/boy-pants.svg',
    images: ['/assets/products/kids/boy-pants.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-k-4': {
    id: 'prod-k-4',
    name: 'Girls Floral Embroidered Cotton Frock Dress',
    category: 'Kids Collection',
    subcategory: 'Kids Dresses',
    brand: 'AC Juniors',
    gender: 'kids',
    price: 2950,
    stock: 18,
    soldCount: 12,
    isNew: true,
    description: 'Delightful pure lawn frock dress decorated with pastel thread floral motifs along the neckline and hemline. Includes soft cotton lining.',
    colors: ['Rose Pink', 'Sky Blue'],
    sizes: ['3-4Y', '5-6Y', '7-8Y'],
    image: '/assets/products/kids/girl-dress.svg',
    images: ['/assets/products/kids/girl-dress.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-k-5': {
    id: 'prod-k-5',
    name: 'Boys Traditional Festive Kurta Shalwar Set',
    category: 'Kids Collection',
    subcategory: 'Kids Shalwar Qameez',
    brand: 'AC Juniors',
    gender: 'kids',
    price: 3450,
    stock: 16,
    soldCount: 25,
    isNew: true,
    description: 'Traditional Eid & festive 2-piece kurta shalwar set tailored in fine cotton with thread detailing on the ban collar and placket.',
    colors: ['Crisp White', 'Pale Mint'],
    sizes: ['4-5Y', '6-7Y', '8-9Y'],
    image: '/assets/products/kids/boy-kurta.svg',
    images: ['/assets/products/kids/boy-kurta.svg'],
    createdAt: new Date().toISOString()
  },

  // Accessories
  'prod-a-1': {
    id: 'prod-a-1',
    name: "Men's Handcrafted Full-Grain Leather Belt",
    category: 'Accessories',
    subcategory: 'Belts',
    brand: 'AC Leathercraft',
    gender: 'accessories',
    price: 1950,
    stock: 40,
    soldCount: 34,
    isNew: true,
    description: 'Genuine full-grain buffalo leather belt hand-finished with beveled edges and a brushed nickel buckle. Pairs with formal trousers or casual denim.',
    colors: ['Tan Brown', 'Ebony Black'],
    sizes: ['32', '34', '36', '38'],
    image: '/assets/products/accessories/leather-belt.svg',
    images: ['/assets/products/accessories/leather-belt.svg'],
    createdAt: new Date().toISOString()
  },
  'prod-a-2': {
    id: 'prod-a-2',
    name: 'Luxury Metallic Cufflinks & Tie Bar Set',
    category: 'Accessories',
    subcategory: 'Other clothing accessories',
    brand: 'AC Sartorial',
    gender: 'accessories',
    price: 2200,
    stock: 30,
    soldCount: 16,
    isNew: false,
    description: 'Presented in a velvet jewelry case, this set includes rhodium-finished engraved cufflinks and a matching spring-loaded tie bar.',
    colors: ['Antique Silver', 'Gold Plated'],
    sizes: ['Standard'],
    image: '/assets/products/accessories/cufflinks.svg',
    images: ['/assets/products/accessories/cufflinks.svg'],
    createdAt: new Date().toISOString()
  }
};

async function ensureCatalogSeeded() {
  try {
    const existingProducts = await db.get('products');
    const existingCategories = await db.get('categories');

    // If products or categories are empty or incomplete, seed them into Firebase RTDB
    if (!existingCategories || Object.keys(existingCategories).length === 0) {
      console.log('[Firebase RTDB] Seeding categories...');
      await db.set('categories', INITIAL_CATEGORIES);
    }

    if (!existingProducts || Object.keys(existingProducts).length < 20) {
      console.log('[Firebase RTDB] Seeding products catalog (23 items)...');
      await db.set('products', INITIAL_PRODUCTS);
    }

    // Seed default coupons if not present
    const existingCoupons = await db.get('coupons');
    if (!existingCoupons || Object.keys(existingCoupons).length === 0) {
      console.log('[Firebase RTDB] Seeding initial promotional coupons...');
      await db.set('coupons', {
        'coup-welcome10': {
          code: 'WELCOME10',
          discountType: 'percentage',
          discountValue: 10,
          minOrderValue: 2000,
          isActive: true,
          description: '10% off on your luxury wardrobe addition'
        },
        'coup-acluxury20': {
          code: 'ACLUXURY20',
          discountType: 'percentage',
          discountValue: 20,
          minOrderValue: 10000,
          isActive: true,
          description: '20% off on premium pret and bridal collections'
        },
        'coup-freeship': {
          code: 'FREESHIP',
          discountType: 'fixed',
          discountValue: 250,
          minOrderValue: 1500,
          isActive: true,
          description: 'Complimentary shipping across Pakistan'
        }
      });
    }

    // Seed Store Settings if not present
    const existingSettings = await db.get('settings');
    if (!existingSettings) {
      await db.set('settings', {
        storeName: 'AC CLOTHING',
        tagline: 'Wear Your Style',
        shippingFeeDefault: 250,
        freeShippingThreshold: 5000,
        contactPhone: '+92 42 3578 9900',
        contactEmail: 'concierge@acclothing.pk',
        contactAddress: 'AC Fashion House, 42-MM Alam Road, Gulberg III, Lahore, Pakistan',
        currency: 'PKR',
        currencySymbol: 'Rs.'
      });
    }

    // Seed Banners if not present
    const existingBanners = await db.get('banners');
    if (!existingBanners || Object.keys(existingBanners).length === 0) {
      await db.set('banners', {
        'banner-1': {
          title: 'Spring / Summer 2026 Collection',
          subtitle: 'Unstitched Luxury Swiss Lawn & Festive Pret',
          badge: 'NEW LAUNCH 2026',
          ctaLink: '/shop.html?category=womens-collection',
          isActive: true
        },
        'banner-2': {
          title: 'The Gentleman Sartorial Edition',
          subtitle: 'Tailored Pique Polos & Royal Boski Shalwar Qameez',
          badge: 'FEATURED',
          ctaLink: '/shop.html?category=mens-collection',
          isActive: true
        }
      });
    }

    // Ensure Admin account metadata
    const adminEmail = process.env.ADMIN_EMAIL || 'tariqadmin@gmail.com';
    const users = await db.get('users');
    let adminFound = false;
    if (users) {
      for (const [uid, u] of Object.entries(users)) {
        if (u.email && u.email.toLowerCase() === adminEmail.toLowerCase()) {
          adminFound = true;
          if (u.role !== 'admin') {
            await db.update(`users/${uid}`, { role: 'admin' });
            console.log(`[Firebase RTDB] Elevated user ${adminEmail} to admin role.`);
          }
          break;
        }
      }
    }

    if (!adminFound) {
      const bcrypt = require('bcryptjs');
      const salt = await bcrypt.genSalt(10);
      const hash = await bcrypt.hash(process.env.ADMIN_PASSWORD || 'AdminPassword123!', salt);
      await db.set('users/admin_tariq', {
        uid: 'admin_tariq',
        id: 'admin_tariq',
        name: 'Tariq (AC Admin)',
        email: adminEmail.toLowerCase(),
        password: hash,
        role: 'admin',
        walletBalance: 30000,
        walletGranted: true,
        createdAt: new Date().toISOString()
      });
      console.log(`[Firebase RTDB] Initialized Administrator profile for ${adminEmail}`);
    }

    console.log('[Firebase RTDB] Catalog check completed successfully.');
  } catch (err) {
    console.warn('[Firebase RTDB] Error checking/seeding catalog:', err.message);
  }
}

module.exports = {
  INITIAL_CATEGORIES,
  INITIAL_PRODUCTS,
  ensureCatalogSeeded
};
