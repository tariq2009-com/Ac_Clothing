/**
 * AC CLOTHING — Firebase Realtime Database Engine
 * Firebase is the ONLY database/backend data solution.
 * Database URL: https://acclothing-default-rtdb.firebaseio.com
 */

const FIREBASE_DB_URL = (process.env.FIREBASE_DATABASE_URL || 'https://acclothing-default-rtdb.firebaseio.com').replace(/\/+$/, '');

class FirebaseDB {
  constructor() {
    this.baseUrl = FIREBASE_DB_URL;
  }

  async get(path) {
    const cleanPath = path.replace(/^\/+|\/+$/g, '');
    const url = `${this.baseUrl}/${cleanPath}.json`;
    const res = await fetch(url);
    if (!res.ok) {
      throw new Error(`Firebase RTDB GET failed: ${res.statusText} (${res.status})`);
    }
    return await res.json();
  }

  async set(path, data) {
    const cleanPath = path.replace(/^\/+|\/+$/g, '');
    const url = `${this.baseUrl}/${cleanPath}.json`;
    const res = await fetch(url, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      throw new Error(`Firebase RTDB SET failed: ${res.statusText} (${res.status})`);
    }
    return await res.json();
  }

  async update(path, data) {
    const cleanPath = path.replace(/^\/+|\/+$/g, '');
    const url = `${this.baseUrl}/${cleanPath}.json`;
    const res = await fetch(url, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      throw new Error(`Firebase RTDB UPDATE failed: ${res.statusText} (${res.status})`);
    }
    return await res.json();
  }

  async push(path, data) {
    const cleanPath = path.replace(/^\/+|\/+$/g, '');
    const url = `${this.baseUrl}/${cleanPath}.json`;
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    });
    if (!res.ok) {
      throw new Error(`Firebase RTDB PUSH failed: ${res.statusText} (${res.status})`);
    }
    const result = await res.json();
    return result.name;
  }

  async remove(path) {
    const cleanPath = path.replace(/^\/+|\/+$/g, '');
    const url = `${this.baseUrl}/${cleanPath}.json`;
    const res = await fetch(url, {
      method: 'DELETE'
    });
    if (!res.ok) {
      throw new Error(`Firebase RTDB DELETE failed: ${res.statusText} (${res.status})`);
    }
    return true;
  }
}

const db = new FirebaseDB();

// Helper to normalize product object with IDs and images
function normalizeProduct(raw, key) {
  if (!raw) return null;
  const id = raw.id || key;
  const images = Array.isArray(raw.images) && raw.images.length > 0 
    ? raw.images 
    : (raw.image ? [raw.image] : ['/assets/products/men/polo-tee.svg']);
  
  return {
    _id: id,
    id: id,
    slug: raw.slug || id,
    name: raw.name || 'AC Product',
    category: raw.category || "Men's Collection",
    subcategory: raw.subcategory || '',
    brand: raw.brand || 'AC CLOTHING',
    gender: raw.gender || 'unisex',
    price: Number(raw.price) || 0,
    compareAtPrice: raw.compareAtPrice ? Number(raw.compareAtPrice) : null,
    stock: raw.stock !== undefined ? Number(raw.stock) : 20,
    soldCount: Number(raw.soldCount) || 0,
    isNew: raw.isNew !== undefined ? Boolean(raw.isNew) : true,
    isNewArrival: raw.isNew !== undefined ? Boolean(raw.isNew) : true,
    description: raw.description || '',
    colors: Array.isArray(raw.colors) ? raw.colors : (raw.colors ? [raw.colors] : ['Default']),
    sizes: Array.isArray(raw.sizes) ? raw.sizes : (raw.sizes ? [raw.sizes] : ['Standard']),
    images: images,
    image: images[0],
    fabric: raw.fabric || 'Pure Combed Cotton',
    createdAt: raw.createdAt || new Date().toISOString()
  };
}

// Product helpers
async function getProducts() {
  const data = await db.get('products');
  if (!data) return [];
  return Object.entries(data).map(([key, val]) => normalizeProduct(val, key));
}

async function getProductById(id) {
  const products = await db.get('products');
  if (!products) return null;
  if (products[id]) return normalizeProduct(products[id], id);
  for (const [key, p] of Object.entries(products)) {
    if (p.id === id || p.slug === id || key === id) {
      return normalizeProduct(p, key);
    }
  }
  return null;
}

async function saveProduct(product) {
  const id = product.id || product._id || `prod-${Date.now()}`;
  const normalized = normalizeProduct(product, id);
  await db.set(`products/${id}`, normalized);
  return normalized;
}

async function updateProduct(id, updates) {
  const existing = await getProductById(id);
  if (!existing) throw new Error('Product not found');
  const merged = { ...existing, ...updates, id: existing.id, _id: existing.id };
  await db.update(`products/${existing.id}`, merged);
  return merged;
}

async function deleteProduct(id) {
  const existing = await getProductById(id);
  if (!existing) return true;
  return await db.remove(`products/${existing.id}`);
}

// Categories helpers
async function getCategories() {
  const data = await db.get('categories');
  if (!data) return [];
  return Object.entries(data).map(([key, val]) => ({
    slug: val.slug || key,
    name: val.name || key,
    gender: val.gender || 'all',
    description: val.description || '',
    image: val.image || ''
  }));
}

// Orders helpers
async function getOrders() {
  const data = await db.get('orders');
  if (!data) return [];
  return Object.entries(data).map(([key, val]) => ({
    _id: key,
    id: key,
    ...val
  })).sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));
}

async function getOrderById(id) {
  const orders = await db.get('orders');
  if (!orders) return null;
  if (orders[id]) return { _id: id, id, ...orders[id] };
  for (const [key, o] of Object.entries(orders)) {
    if (o.orderNumber === id || o.id === id || key === id) {
      return { _id: key, id: key, ...o };
    }
  }
  return null;
}

async function createOrder(orderData) {
  const orderId = `AC-${new Date().toISOString().slice(0, 10).replace(/-/g, '')}-${Math.floor(1000 + Math.random() * 9000)}`;
  const order = {
    orderNumber: orderId,
    id: orderId,
    createdAt: new Date().toISOString(),
    status: 'Pending',
    ...orderData
  };

  await db.set(`orders/${orderId}`, order);

  // If user is specified, also link to userOrders
  if (orderData.userId) {
    await db.set(`userOrders/${orderData.userId}/${orderId}`, true);
  }

  // Adjust stock for purchased items
  if (Array.isArray(orderData.items)) {
    for (const item of orderData.items) {
      const pId = item.productId || item.id || item._id;
      if (pId) {
        try {
          const product = await getProductById(pId);
          if (product) {
            const newStock = Math.max(0, (product.stock || 0) - (item.quantity || 1));
            const newSold = (product.soldCount || 0) + (item.quantity || 1);
            await db.update(`products/${product.id}`, { stock: newStock, soldCount: newSold });
          }
        } catch (e) {
          console.warn('Failed to decrement product stock:', e.message);
        }
      }
    }
  }

  // If paid with wallet, deduct balance and record transaction
  if (orderData.paymentMethod === 'wallet' && orderData.userId) {
    try {
      const userRefPath = `users/${orderData.userId}`;
      const user = await db.get(userRefPath);
      if (user) {
        const curBalance = Number(user.walletBalance) || 0;
        const newBalance = Math.max(0, curBalance - Number(orderData.totalAmount || 0));
        await db.update(userRefPath, { walletBalance: newBalance });

        // Record wallet transaction
        const txPath = `transactions/${orderData.userId}`;
        await db.push(txPath, {
          type: 'DEBIT',
          amount: Number(orderData.totalAmount || 0),
          orderId: orderId,
          description: `Order Payment for #${orderId}`,
          balanceAfter: newBalance,
          date: new Date().toISOString()
        });
      }
    } catch (e) {
      console.error('Wallet deduction error:', e.message);
    }
  }

  return order;
}

// User Helpers
async function getUsers() {
  const data = await db.get('users');
  if (!data) return [];
  return Object.entries(data).map(([key, val]) => ({
    uid: key,
    _id: key,
    ...val
  }));
}

async function getUserById(uid) {
  const user = await db.get(`users/${uid}`);
  if (!user) return null;
  return { uid, _id: uid, ...user };
}

async function getUserByEmail(email) {
  const users = await db.get('users');
  if (!users) return null;
  const target = email.toLowerCase().trim();
  for (const [uid, u] of Object.entries(users)) {
    if (u.email && u.email.toLowerCase().trim() === target) {
      return { uid, _id: uid, ...u };
    }
  }
  return null;
}

// Coupons helpers
async function getCoupons() {
  const data = await db.get('coupons');
  if (!data) return [];
  return Object.entries(data).map(([key, val]) => ({
    _id: key,
    id: key,
    ...val
  }));
}

async function getCouponByCode(code) {
  const coupons = await db.get('coupons');
  if (!coupons) return null;
  const cleanCode = code.toUpperCase().trim();
  for (const [key, c] of Object.entries(coupons)) {
    if (c.code && c.code.toUpperCase().trim() === cleanCode) {
      return { _id: key, id: key, ...c };
    }
  }
  return null;
}

// Reviews helpers
async function getReviews() {
  const data = await db.get('reviews');
  if (!data) return [];
  return Object.entries(data).map(([key, val]) => ({
    _id: key,
    id: key,
    ...val
  }));
}

module.exports = {
  db,
  FIREBASE_DB_URL,
  normalizeProduct,
  getProducts,
  getProductById,
  saveProduct,
  updateProduct,
  deleteProduct,
  getCategories,
  getOrders,
  getOrderById,
  createOrder,
  getUsers,
  getUserById,
  getUserByEmail,
  getCoupons,
  getCouponByCode,
  getReviews
};
