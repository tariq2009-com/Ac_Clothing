/**
 * AC CLOTHING — Firebase Database Seeder
 * Connects and seeds products, categories, coupons, and settings to Firebase Realtime Database.
 * MongoDB is completely removed.
 */

const { ensureCatalogSeeded } = require('./catalog');

async function seedDatabase(force = false) {
  try {
    await ensureCatalogSeeded();
    console.log('[Firebase Seeder] Catalog verified successfully.');
  } catch (err) {
    console.error('[Firebase Seeder] Error seeding catalog:', err);
  }
}

module.exports = {
  seedDatabase
};
