/**
 * AC CLOTHING — Core Application Engine
 * Handles theme switching, living background controls, header height measurement,
 * cart & wishlist synchronization, user auth state, and toast notifications.
 */

// Ensure window.fetch has both getter and setter so parent iframe wrappers/interceptors can patch it without throwing
(function() {
  try {
    let _f = window.fetch;
    Object.defineProperty(window, 'fetch', {
      get() { return _f; },
      set(val) { _f = val; },
      configurable: true,
      enumerable: true
    });
  } catch (e) {}
})();

// 1. Theme Management (Default: Light / Theme 1)
function initTheme() {
  const savedTheme = localStorage.getItem('ac_theme') || 'light';
  applyTheme(savedTheme);

  document.querySelectorAll('.ac-theme-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const current = document.documentElement.getAttribute('data-theme') === 'dark' ? 'dark' : 'light';
      const next = current === 'dark' ? 'light' : 'dark';
      applyTheme(next);
    });
  });
}

function applyTheme(theme) {
  if (theme === 'dark') {
    document.documentElement.setAttribute('data-theme', 'dark');
  } else {
    document.documentElement.removeAttribute('data-theme');
  }
  localStorage.setItem('ac_theme', theme);
  updateThemeToggleLabels(theme);
}

function updateThemeToggleLabels(theme) {
  document.querySelectorAll('.ac-theme-toggle').forEach(btn => {
    const isDark = theme === 'dark';
    btn.innerHTML = isDark
      ? `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg><span>Light</span>`
      : `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg><span>Dark</span>`;
  });
}

// 2. Fixed Header Dynamic Height Measurement
function initHeaderMeasurement() {
  const header = document.querySelector('.ac-header');
  if (!header) return;

  const updateHeaderH = () => {
    const h = header.getBoundingClientRect().height;
    document.documentElement.style.setProperty('--header-h', `${Math.round(h)}px`);
  };

  updateHeaderH();
  window.addEventListener('resize', updateHeaderH, { passive: true });

  if (window.ResizeObserver) {
    const ro = new ResizeObserver(() => updateHeaderH());
    ro.observe(header);
  }
}

// 3. Living Background Lifecycle (Pause on tab blur for peak performance)
function initLivingBgLifecycle() {
  const aura = document.querySelector('.ac-aura');
  if (!aura) return;

  document.addEventListener('visibilitychange', () => {
    if (document.hidden) {
      aura.classList.add('ac-aura-paused');
    } else {
      aura.classList.remove('ac-aura-paused');
    }
  });
}

// 4. PKR Currency Formatter
function formatPKR(amount) {
  const num = Number(amount) || 0;
  return `Rs. ${num.toLocaleString('en-PK')}`;
}

// 5. Toast Notifications
function showToast(message, type = 'info') {
  let container = document.querySelector('.ac-toast-container');
  if (!container) {
    container = document.createElement('div');
    container.className = 'ac-toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'ac-toast';
  
  const icon = type === 'success'
    ? `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#0E9C82" stroke-width="2.5"><polyline points="20 6 9 17 4 12"/></svg>`
    : `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#F04E32" stroke-width="2.5"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`;

  toast.innerHTML = `${icon}<span>${message}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(30px)';
    toast.style.transition = 'all 0.3s ease';
    setTimeout(() => toast.remove(), 300);
  }, 3500);
}

// 6. Cart Storage & Sync
function getCart() {
  try {
    return JSON.parse(localStorage.getItem('ac_cart') || '[]');
  } catch {
    return [];
  }
}

function saveCart(cart) {
  localStorage.setItem('ac_cart', JSON.stringify(cart));
  updateCartBadge();
  window.dispatchEvent(new CustomEvent('ac:cart-updated', { detail: cart }));
}

function addToCart(product, quantity = 1, size = 'Standard', color = '') {
  const cart = getCart();
  const existingIdx = cart.findIndex(item =>
    item.productId === product._id && item.size === size && item.color === color
  );

  if (existingIdx > -1) {
    cart[existingIdx].quantity += quantity;
  } else {
    cart.push({
      productId: product._id,
      slug: product.slug,
      name: product.name,
      price: product.price,
      quantity,
      size,
      color,
      image: (product.images && product.images[0]) || '',
      fabric: product.fabric,
      stock: product.stock
    });
  }

  saveCart(cart);
  showToast(`Added ${quantity} × ${product.name} to bag`, 'success');
}

function updateCartBadge() {
  const cart = getCart();
  const totalCount = cart.reduce((sum, item) => sum + (item.quantity || 1), 0);
  document.querySelectorAll('.ac-cart-count').forEach(el => {
    el.textContent = totalCount;
    el.style.display = totalCount > 0 ? 'flex' : 'none';
  });
}

// 7. Wishlist Storage & Sync
function getWishlist() {
  try {
    return JSON.parse(localStorage.getItem('ac_wishlist') || '[]');
  } catch {
    return [];
  }
}

function toggleWishlist(productId) {
  let list = getWishlist();
  const idx = list.indexOf(productId);
  let added = false;
  if (idx > -1) {
    list.splice(idx, 1);
  } else {
    list.push(productId);
    added = true;
  }
  localStorage.setItem('ac_wishlist', JSON.stringify(list));
  updateWishlistBadge();
  window.dispatchEvent(new CustomEvent('ac:wishlist-updated', { detail: list }));
  showToast(added ? 'Saved to wishlist' : 'Removed from wishlist', 'info');
  return added;
}

function updateWishlistBadge() {
  const list = getWishlist();
  document.querySelectorAll('.ac-wishlist-count').forEach(el => {
    el.textContent = list.length;
    el.style.display = list.length > 0 ? 'flex' : 'none';
  });
}

// 8. Auth State Sync
function getAuthUser() {
  try {
    const raw = localStorage.getItem('ac_user');
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

function getAuthToken() {
  return localStorage.getItem('ac_token');
}

function setAuthSession(token, user) {
  localStorage.setItem('ac_token', token);
  localStorage.setItem('ac_user', JSON.stringify(user));
  updateAuthUI();
}

function clearAuthSession() {
  localStorage.removeItem('ac_token');
  localStorage.removeItem('ac_user');
  fetch('/api/auth/logout', { method: 'POST' }).catch(() => {});
  updateAuthUI();
  window.location.href = '/login.html';
}

function updateAuthUI() {
  const user = getAuthUser();
  document.querySelectorAll('.ac-auth-link').forEach(link => {
    if (user) {
      link.href = user.role === 'admin' ? '/admin/index.html' : '/account.html';
      link.title = `Signed in as ${user.name}`;
      const textSpan = link.querySelector('.ac-nav-text');
      if (textSpan) textSpan.textContent = user.role === 'admin' ? 'Admin' : user.name.split(' ')[0];
    } else {
      link.href = '/login.html';
      link.title = 'Sign In';
      const textSpan = link.querySelector('.ac-nav-text');
      if (textSpan) textSpan.textContent = 'Account';
    }
  });
}

// 9. Mobile Menu
function initMobileMenu() {
  const toggle = document.querySelector('.ac-mobile-toggle');
  const menu = document.querySelector('.ac-mobile-menu');
  if (toggle && menu) {
    toggle.addEventListener('click', () => {
      menu.classList.toggle('open');
    });
  }
}

// 10. Global Search Input Trigger
function initGlobalSearch() {
  const searchInputs = document.querySelectorAll('.ac-search-input');
  searchInputs.forEach(input => {
    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter' && input.value.trim()) {
        window.location.href = `/shop.html?search=${encodeURIComponent(input.value.trim())}`;
      }
    });
  });
}

// Auto Initialize on DOM Ready
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initHeaderMeasurement();
  initLivingBgLifecycle();
  updateCartBadge();
  updateWishlistBadge();
  updateAuthUI();
  initMobileMenu();
  initGlobalSearch();
});
