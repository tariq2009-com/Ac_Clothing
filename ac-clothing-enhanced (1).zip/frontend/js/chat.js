/**
 * AC CLOTHING — Floating AI Shopping Assistant ("Your Assistant")
 * Features 20px border radius, typing indicator, suggestion chips,
 * persisted conversation history, and "New chat" reset button.
 */

class ACAssistantWidget {
  constructor() {
    this.historyKey = 'ac_assistant_history';
    this.messages = this.loadHistory();
    this.isOpen = false;
    this.isTyping = false;
    this.init();
  }

  loadHistory() {
    try {
      const stored = localStorage.getItem(this.historyKey);
      if (stored) return JSON.parse(stored);
    } catch {}
    return [
      {
        role: 'assistant',
        content: "Welcome to AC CLOTHING. I am **Your Assistant**. I can help you discover our premium Lawn suites, Ready-to-Wear Pret, Chiffon formals, or Men's Kurtas. Ask me anything or explore using the quick suggestions below!"
      }
    ];
  }

  saveHistory() {
    try {
      localStorage.setItem(this.historyKey, JSON.stringify(this.messages));
    } catch {}
  }

  init() {
    this.renderWidget();
    this.bindEvents();
    this.renderMessages();
  }

  renderWidget() {
    const existing = document.getElementById('ac-assistant-container');
    if (existing) return;

    const container = document.createElement('div');
    container.id = 'ac-assistant-container';
    container.className = 'ac-chat-widget';

    container.innerHTML = `
      <!-- Launcher Toggle Button -->
      <button class="ac-chat-toggle-btn" aria-label="Open AI Assistant" title="Your Assistant">
        <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          <path d="M8 10h.01M12 10h.01M16 10h.01" stroke-width="3" stroke-linecap="round"/>
        </svg>
      </button>

      <!-- Chat Floating Modal (20px border-radius) -->
      <div class="ac-chat-panel" role="dialog" aria-modal="true" aria-label="Your Shopping Assistant">
        <div class="ac-chat-header">
          <div class="ac-chat-title-group">
            <div class="ac-chat-avatar">AC</div>
            <div>
              <div class="ac-chat-name">Your Assistant</div>
              <div class="ac-chat-sub">Online & Ready</div>
            </div>
          </div>
          <div class="ac-chat-actions">
            <button class="ac-chat-btn-reset" title="Clear chat history">New chat</button>
            <button class="ac-icon-btn ac-chat-btn-close" aria-label="Close assistant">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <line x1="18" y1="6" x2="6" y2="18"/>
                <line x1="6" y1="6" x2="18" y2="18"/>
              </svg>
            </button>
          </div>
        </div>

        <div class="ac-chat-messages" id="ac-chat-msg-list"></div>

        <!-- Suggestion Chips -->
        <div class="ac-chat-chips">
          <button class="ac-chip" data-query="Show me 3pc Lawn suits">3pc Lawn Suits</button>
          <button class="ac-chip" data-query="Men's Boski Kurta collection">Men's Boski</button>
          <button class="ac-chip" data-query="Under 6000 budget suits">Under Rs. 6,000</button>
          <button class="ac-chip" data-query="Active promo discount codes">Coupons</button>
          <button class="ac-chip" data-query="Delivery time and COD charges">Shipping Policy</button>
          <button class="ac-chip" data-query="Mujhe koi acha lawn suit dikhao">Roman Urdu Help</button>
        </div>

        <!-- Input Area -->
        <form class="ac-chat-input-area" id="ac-chat-form">
          <input
            type="text"
            class="ac-chat-input"
            id="ac-chat-input-field"
            placeholder="Ask anything..."
            autocomplete="off"
            maxlength="400"
          />
          <button type="submit" class="ac-chat-send" aria-label="Send message">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2">
              <line x1="22" y1="2" x2="11" y2="13"/>
              <polygon points="22 2 15 22 11 13 2 9 22 2"/>
            </svg>
          </button>
        </form>
      </div>
    `;

    document.body.appendChild(container);
  }

  bindEvents() {
    const toggleBtn = document.querySelector('.ac-chat-toggle-btn');
    const panel = document.querySelector('.ac-chat-panel');
    const closeBtn = document.querySelector('.ac-chat-btn-close');
    const resetBtn = document.querySelector('.ac-chat-btn-reset');
    const form = document.getElementById('ac-chat-form');
    const input = document.getElementById('ac-chat-input-field');

    toggleBtn.addEventListener('click', () => {
      this.isOpen = !this.isOpen;
      panel.classList.toggle('open', this.isOpen);
      if (this.isOpen) {
        input.focus();
        this.scrollToBottom();
      }
    });

    closeBtn.addEventListener('click', () => {
      this.isOpen = false;
      panel.classList.remove('open');
    });

    resetBtn.addEventListener('click', () => {
      this.resetChat();
    });

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      const val = input.value.trim();
      if (!val || this.isTyping) return;
      input.value = '';
      this.sendMessage(val);
    });

    // Chips click handler
    document.querySelectorAll('.ac-chip').forEach(chip => {
      chip.addEventListener('click', () => {
        const query = chip.getAttribute('data-query');
        if (query && !this.isTyping) {
          this.sendMessage(query);
        }
      });
    });
  }

  async sendMessage(text) {
    // Add user message
    this.messages.push({ role: 'user', content: text });
    this.renderMessages();
    this.saveHistory();

    // Show typing indicator
    this.isTyping = true;
    this.renderTypingIndicator();

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: this.messages.slice(-8)
        })
      });

      const data = await res.json();
      const reply = data.reply || "I am currently syncing with the boutique catalogue. Please ask again in a moment.";

      this.removeTypingIndicator();
      this.messages.push({ role: 'assistant', content: reply });
      this.saveHistory();
      this.renderMessages();
    } catch (err) {
      this.removeTypingIndicator();
      this.messages.push({
        role: 'assistant',
        content: "We are currently experiencing a brief connection delay. Please feel free to explore our collections directly through the navigation menu."
      });
      this.saveHistory();
      this.renderMessages();
    } finally {
      this.isTyping = false;
    }
  }

  resetChat() {
    this.messages = [
      {
        role: 'assistant',
        content: "New chat started. How can I assist you with AC CLOTHING fabrics, sizes, or orders?"
      }
    ];
    this.saveHistory();
    this.renderMessages();
  }

  formatMarkdown(raw) {
    if (!raw) return '';
    let escaped = raw
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');

    // Render catalogue images only from our local product asset folder.
    escaped = escaped.replace(/!\[([^\]]*)\]\((\/assets\/products\/[a-zA-Z0-9_./-]+\.svg)\)/g,
      '<img class="ac-chat-product-image" src="$2" alt="$1" loading="lazy">');

    // Bold **text**
    escaped = escaped.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');

    // Bullet lines: lines starting with "- " or "• "
    const lines = escaped.split('\n');
    let inList = false;
    let html = '';

    for (const line of lines) {
      const trimmed = line.trim();
      if (trimmed.startsWith('- ') || trimmed.startsWith('• ')) {
        if (!inList) {
          html += '<ul>';
          inList = true;
        }
        html += `<li>${trimmed.substring(2)}</li>`;
      } else {
        if (inList) {
          html += '</ul>';
          inList = false;
        }
        if (trimmed) {
          html += `<p style="margin-bottom: 6px;">${trimmed}</p>`;
        }
      }
    }
    if (inList) html += '</ul>';
    return html;
  }

  renderMessages() {
    const list = document.getElementById('ac-chat-msg-list');
    if (!list) return;

    list.innerHTML = this.messages.map(msg => {
      const cls = msg.role === 'user' ? 'ac-msg-user' : 'ac-msg-assistant';
      const content = msg.role === 'user'
        ? msg.content.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
        : this.formatMarkdown(msg.content);
      return `<div class="ac-msg ${cls}">${content}</div>`;
    }).join('');

    this.scrollToBottom();
  }

  renderTypingIndicator() {
    const list = document.getElementById('ac-chat-msg-list');
    if (!list) return;

    const existing = document.getElementById('ac-typing-box');
    if (existing) return;

    const ind = document.createElement('div');
    ind.id = 'ac-typing-box';
    ind.className = 'ac-typing-indicator';
    ind.innerHTML = `
      <span class="ac-typing-dot"></span>
      <span class="ac-typing-dot"></span>
      <span class="ac-typing-dot"></span>
    `;
    list.appendChild(ind);
    this.scrollToBottom();
  }

  removeTypingIndicator() {
    const existing = document.getElementById('ac-typing-box');
    if (existing) existing.remove();
  }

  scrollToBottom() {
    const list = document.getElementById('ac-chat-msg-list');
    if (list) {
      list.scrollTop = list.scrollHeight;
    }
  }
}

// Auto instantiate on load
document.addEventListener('DOMContentLoaded', () => {
  window.acAssistant = new ACAssistantWidget();
});
