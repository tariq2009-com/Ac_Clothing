/**
 * AC CLOTHING — Netlify Serverless Function
 */
const serverless = require('serverless-http');
const { app } = require('../../backend/server');

const handler = serverless(app, {
  request: (req, event, context) => {
    // Netlify Buffer handling for POST/PUT requests
    if (event.body) {
      if (event.isBase64Encoded) {
        req.body = Buffer.from(event.body, 'base64');
      } else if (typeof event.body === 'string') {
        try {
          req.body = JSON.parse(event.body);
        } catch {
          req.body = Buffer.from(event.body);
        }
      }
    }
  }
});

module.exports.handler = async (event, context) => {
  context.callbackWaitsForEmptyEventLoop = false;
  return await handler(event, context);
};
