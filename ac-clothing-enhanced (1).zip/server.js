/**
 * AC CLOTHING — Root Server Entry
 * Delegates to backend/server.js
 */
const { app, start } = require('./backend/server');

const port = process.env.PORT || 3000;

if (require.main === module) {
  start(port);
}

module.exports = { app, start };
