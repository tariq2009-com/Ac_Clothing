/**
 * AC CLOTHING — Root Server Entry for Dev & Full-Stack Runtimes
 */
import { createRequire } from 'module';
const require = createRequire(import.meta.url);

const { app, start } = require('./backend/server.js');

const port = 3000;

start(port);

export { app, start };
