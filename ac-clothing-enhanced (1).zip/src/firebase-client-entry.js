import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  signInWithPopup,
  GoogleAuthProvider,
  signOut,
  onAuthStateChanged,
  sendPasswordResetEmail,
  updateProfile
} from 'firebase/auth';
import {
  getDatabase,
  ref,
  get,
  set,
  update,
  push,
  remove,
  onValue,
  child,
  runTransaction
} from 'firebase/database';

const firebaseConfig = {
  apiKey: "AIzaSyBgGpHdx2cChzy0qXLbL1bNGH_-Fsmx7A",
  authDomain: "acclothing.firebaseapp.com",
  databaseURL: "https://acclothing-default-rtdb.firebaseio.com",
  projectId: "acclothing",
  storageBucket: "acclothing.firebasestorage.app",
  messagingSenderId: "599008010809",
  appId: "1:599008010809:web:5e175195e377f8fb0263e8"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const database = getDatabase(app);
const googleProvider = new GoogleAuthProvider();

// AC Clothing Wallet constant: Rs. 30,000 virtual store credit
const INITIAL_WALLET_BALANCE = 30000;
const ADMIN_EMAIL = 'tariqadmin@gmail.com';

/**
 * Handle new user registration or Google login in Realtime Database.
 * Gives exactly Rs. 30,000 initial wallet balance once.
 */
async function syncUserProfile(user, extra = {}) {
  if (!user || !user.uid) return null;
  const userRef = ref(database, `users/${user.uid}`);
  const snapshot = await get(userRef);

  const isAdmin = (user.email && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase()) || extra.role === 'admin';
  const role = isAdmin ? 'admin' : 'customer';

  if (!snapshot.exists()) {
    // Brand new user: Grant initial Rs. 30,000 wallet balance
    const profile = {
      uid: user.uid,
      name: extra.name || user.displayName || user.email.split('@')[0],
      email: user.email.toLowerCase(),
      phone: extra.phone || '',
      role: role,
      walletBalance: INITIAL_WALLET_BALANCE,
      walletGranted: true,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    await set(userRef, profile);

    // Record initial welcome credit transaction
    const txRef = ref(database, `transactions/${user.uid}`);
    const newTxRef = push(txRef);
    await set(newTxRef, {
      id: newTxRef.key,
      type: 'CREDIT',
      amount: INITIAL_WALLET_BALANCE,
      description: 'AC Clothing Welcome Gift — Rs. 30,000 Virtual Store Credit',
      balanceAfter: INITIAL_WALLET_BALANCE,
      date: new Date().toISOString()
    });

    return profile;
  } else {
    // Existing user: preserve existing balance & walletGranted flag
    const existing = snapshot.val();
    let updates = {};

    // Keep admin role up to date
    if (isAdmin && existing.role !== 'admin') {
      updates.role = 'admin';
    }
    if (extra.name && !existing.name) {
      updates.name = extra.name;
    }
    if (Object.keys(updates).length > 0) {
      await update(userRef, updates);
      return { ...existing, ...updates };
    }
    return existing;
  }
}

window.AC_FIREBASE = {
  app,
  auth,
  database,
  googleProvider,
  firebaseConfig,
  ADMIN_EMAIL,
  INITIAL_WALLET_BALANCE,
  // Auth methods
  signInWithEmail: (email, password) => signInWithEmailAndPassword(auth, email, password),
  signUpWithEmail: (email, password) => createUserWithEmailAndPassword(auth, email, password),
  signInWithGoogle: () => signInWithPopup(auth, googleProvider),
  logOut: () => signOut(auth),
  onAuthChange: (callback) => onAuthStateChanged(auth, callback),
  sendPasswordReset: (email) => sendPasswordResetEmail(auth, email),
  updateUserProfile: (profile) => updateProfile(auth.currentUser, profile),
  getCurrentUser: () => auth.currentUser,
  // Database methods
  dbRef: (path) => ref(database, path),
  dbGet: (path) => get(ref(database, path)),
  dbSet: (path, data) => set(ref(database, path), data),
  dbUpdate: (path, data) => update(ref(database, path), data),
  dbPush: (path, data) => push(ref(database, path), data),
  dbRemove: (path) => remove(ref(database, path)),
  dbOnValue: (path, cb) => onValue(ref(database, path), cb),
  syncUserProfile
};

console.log('[AC CLOTHING] Firebase Modular Client SDK Loaded.');
